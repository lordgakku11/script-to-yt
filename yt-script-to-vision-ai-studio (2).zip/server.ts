import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import os from 'os';
import { execFile } from 'child_process';
import { promisify } from 'util';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

const execFileAsync = promisify(execFile);

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Parse JSON and raw bodies
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Helper to get GoogleGenAI client
function getGeminiClient(customKey?: string) {
  const apiKey = customKey || process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('No Gemini API key available. Please configure GEMINI_API_KEY in Secrets or provide a key.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// 1. Scene planning endpoint using Gemini
app.post('/api/gemini/analyze', async (req: Request, res: Response) => {
  try {
    const {
      script,
      styleMode = 'stickman',
      aspectRatio = '16:9',
      pacingDensity = 'ultra-granular',
      maxScenes = 'max',
      artAtmosphere = 'default',
      apiKey: userApiKey,
      model = 'gemini-3.8-flash',
    } = req.body;

    if (!script || typeof script !== 'string') {
      res.status(400).json({ error: 'Missing or invalid script content' });
      return;
    }

    const ai = getGeminiClient(userApiKey);

    // Style description
    let styleDesc = '';
    if (styleMode === 'stickman') {
      styleDesc = 'minimalist black ink hand-drawn stick figure line art, clean doodle illustration, expressive face with simple round head and stick limbs, smooth solid clean light gray studio background (#d1d5db / neutral gray), high contrast, viral YouTube explainer animation aesthetic, absolutely no text, no watermark, no captions';
    } else if (styleMode === 'cartoon') {
      styleDesc = 'vibrant 3D Pixar Disney style animated cartoon, rich colors, soft whimsical lighting, expressive stylized characters, detailed cartoon textures, high quality digital animation render, cinematic framing, no text, no watermark, no captions';
    } else {
      let atmoDesc = 'cinematic lighting, dramatic shadows, photorealistic scene, highly detailed';
      if (artAtmosphere === 'dark-thriller') atmoDesc = 'dark atmospheric thriller lighting, deep shadows, moody neon rim light, mysterious fog, 8k cinematic realism';
      if (artAtmosphere === 'humorous-fun') atmoDesc = 'bright cheerful daytime lighting, vivid punchy colors, playful photorealistic framing, sharp focus';
      if (artAtmosphere === 'dramatic-epic') atmoDesc = 'epic cinematic composition, golden hour god rays, dramatic haze, dynamic motion, Hollywood movie still';
      if (artAtmosphere === 'educational-clean') atmoDesc = 'clean studio lighting, soft depth of field, sharp crisp subjects, documentary realism, immaculate detail';
      styleDesc = `${atmoDesc}, photorealistic 8k render, masterpiece composition, no text, no watermark, no captions`;
    }

    let pacingRule = 'Divide the script into GRANULAR micro-scene beats (every 2-3 seconds of speech, or every single clause/phrase). Every visual shift must have its own scene.';
    if (pacingDensity === 'fast') {
      pacingRule = 'Divide the script into fast scenes (every 3-5 seconds of speech).';
    } else if (pacingDensity === 'balanced') {
      pacingRule = 'Divide the script into balanced scenes (every 6-8 seconds of speech).';
    }

    let sceneCountRule = 'Create as many granular micro-scenes as needed to thoroughly cover every line.';
    if (maxScenes !== 'max') {
      sceneCountRule = `Create at least ${maxScenes} distinct scenes.`;
    }

    const prompt = `You are an expert YouTube video director and narration editor.
The user provided a YouTube Video Narration Script below.
Your mission is to divide this EXACT script into sequential scenes for visual generation and scene-by-scene voiceover narration.

CRITICAL VOICE & IMAGE MATCHING RULES:
1. "script_part" MUST be a coherent, complete sentence or full clause from the user's script.
2. Cover the user's entire script in exact chronological order without losing words.
3. Do NOT chop into single words or tiny fragmented clauses. Each scene needs a natural, complete phrase for TTS voiceover.
4. STRICT 1-TO-1 VOICE-TO-IMAGE MATCH: Each scene's "image_prompt" MUST directly and literally illustrate the exact subject, action, emotion, and setting spoken in that scene's "script_part". Never invent unrelated actions (like pointing at a blackboard or laughing) unless explicitly stated in "script_part".
5. Visual Art Style: ${styleMode.toUpperCase()}
   Style details: "${styleDesc}"
   Aspect Ratio: ${aspectRatio}
   Pacing: ${pacingRule}
   Scene count: ${sceneCountRule}

Each scene item in the JSON array must contain:
- "scene_number": sequential integer starting at 1
- "script_part": the exact narration text for this scene to be spoken by TTS voiceover
- "visual_thinking": brief creative director rationale explaining how the visual directly illustrates the spoken narration
- "image_prompt": detailed, vivid prompt for image generation directly depicting the exact spoken line in ${styleMode} style, ${aspectRatio} aspect ratio, no text, no watermark, no captions

YouTube Narration Script:
"""
${script}
"""`;

    let parsed: any[] = [];
    try {
      // Request structured JSON response
      const response = await ai.models.generateContent({
        model: model || 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                scene_number: { type: Type.INTEGER },
                script_part: { type: Type.STRING },
                visual_thinking: { type: Type.STRING },
                image_prompt: { type: Type.STRING },
              },
              required: ['scene_number', 'script_part', 'visual_thinking', 'image_prompt'],
            },
          },
        },
      });

      const rawText = response.text || '[]';
      parsed = JSON.parse(rawText);
    } catch (genErr: any) {
      console.warn('[Gemini Call Warning] Primary model call failed, generating fallback breakdown:', genErr.message);

      // Intelligent rule-based breakdown fallback (sentences / lines, not commas)
      const trimmedScript = script.trim();
      let lines = trimmedScript
        .split(/\r?\n+/)
        .map(l => l.replace(/^(?:\[?(?:Scene|Shot|Beat|Part)\s*\d+\]?:?|\d+[\.\)])\s*/i, '').replace(/^(?:Narration|Voiceover|Voice|Text):\s*/i, '').trim())
        .filter(l => l.length > 0);

      if (lines.length <= 1) {
        lines = trimmedScript
          .split(/(?<=[.!?।;])\s+/)
          .map(s => s.trim())
          .filter(s => s.length > 0);
      }

      const items = lines.length > 0 ? lines : [trimmedScript];
      const shotFramings = [
        'cinematic medium shot',
        'focused close-up shot',
        'wide establishing shot',
        'dramatic eye-level framing',
        'dynamic over-the-shoulder view',
        'expressive three-quarter angle shot',
      ];

      parsed = items.map((clause, idx) => {
        const shot = shotFramings[idx % shotFramings.length];
        return {
          scene_number: idx + 1,
          script_part: clause,
          visual_thinking: `Scene #${idx + 1} (${shot}): Directly illustrates "${clause.slice(0, 45)}..."`,
          image_prompt: `Exact visual illustration of "${clause}". ${shot} directly depicting every detail of: ${clause}. ${styleDesc}, ${aspectRatio} aspect ratio, no text, no watermark, no captions.`,
        };
      });
    }

    res.json({ scenes: parsed });
  } catch (err: any) {
    console.error('[Gemini API Error]:', err);
    res.status(500).json({
      error: err.message || 'Failed to analyze script with Gemini',
    });
  }
});

// 2. Universal CORS proxy endpoint to prevent CORS blocks on Audexum and external APIs
app.all('/api/proxy', async (req: Request, res: Response) => {
  try {
    const targetUrl = (req.query.url as string) || (req.body?.targetUrl as string);
    if (!targetUrl) {
      res.status(400).json({ error: 'Missing target URL in query parameter ?url=...' });
      return;
    }

    const parsedTarget = new URL(targetUrl);
    // Allow external APIs needed by the studio (Audexum, Cloudflare Workers, Pollinations, Puter)
    const allowedHosts = [
      'audexum.com',
      'workers.dev',
      'pollinations.ai',
      'js.puter.com',
      'api.puter.com',
    ];
    const isAllowed = allowedHosts.some(host => parsedTarget.hostname.endsWith(host));
    if (!isAllowed) {
      // Still permit common AI/media domains if valid URL
      console.warn(`[Proxy Warning] Proxying to non-whitelisted host: ${parsedTarget.hostname}`);
    }

    const fetchHeaders: Record<string, string> = {};
    if (req.headers.authorization) {
      fetchHeaders['authorization'] = req.headers.authorization as string;
    }
    if (req.headers['x-api-key']) {
      fetchHeaders['x-api-key'] = req.headers['x-api-key'] as string;
    }
    if (req.headers['content-type']) {
      fetchHeaders['content-type'] = req.headers['content-type'] as string;
    }
    if (req.headers['accept']) {
      fetchHeaders['accept'] = req.headers['accept'] as string;
    } else {
      fetchHeaders['accept'] = '*/*';
    }
    fetchHeaders['user-agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36';

    const fetchOptions: RequestInit = {
      method: req.method,
      headers: fetchHeaders,
    };

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      if (typeof req.body === 'object' && Object.keys(req.body).length > 0) {
        // If targetUrl was passed in body, strip it
        const { targetUrl: _, ...cleanBody } = req.body;
        fetchOptions.body = JSON.stringify(cleanBody);
        if (!fetchHeaders['content-type']) {
          fetchHeaders['content-type'] = 'application/json';
        }
      }
    }

    const upstreamResponse = await fetch(targetUrl, fetchOptions);

    // Forward status
    res.status(upstreamResponse.status);

    // Forward content-type and other essential headers
    const contentType = upstreamResponse.headers.get('content-type');
    if (contentType) {
      res.setHeader('content-type', contentType);
    }
    res.setHeader('access-control-allow-origin', '*');

    // Stream binary or buffer response
    const arrayBuffer = await upstreamResponse.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    res.send(buffer);
  } catch (err: any) {
    console.error('[Proxy Error]:', err);
    res.status(502).json({ error: `Proxy failed: ${err.message}` });
  }
});

// Helper to split text into safe <=180 char chunks on sentence/clause/word boundaries
function splitTextIntoTtsChunks(text: string, maxLen: number = 180): string[] {
  const cleaned = text.replace(/\s+/g, ' ').trim();
  if (!cleaned) return [];
  if (cleaned.length <= maxLen) return [cleaned];

  const chunks: string[] = [];
  const words = cleaned.split(' ');
  let current = '';

  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (candidate.length > maxLen) {
      if (current) {
        chunks.push(current);
        current = word.slice(0, maxLen);
      } else {
        chunks.push(word.slice(0, maxLen));
        current = '';
      }
    } else {
      current = candidate;
    }
  }
  if (current) chunks.push(current);
  return chunks;
}

// 3. Free High-Quality Neural TTS Fallback Endpoint (Multi-Voice & Unlimited Length)
app.get('/api/tts', async (req: Request, res: Response) => {
  try {
    const text = ((req.query.text as string) || '').trim();
    const lang = ((req.query.lang as string) || 'en').trim();
    const voice = ((req.query.voice as string) || 'M1').trim();

    if (!text) {
      res.status(400).json({ error: 'Text query parameter is required' });
      return;
    }

    const chunks = splitTextIntoTtsChunks(text, 180);

    // Tier 1: Try Neural Voice TTS (supports distinct Male M1/Atlas and Female F1 voices with zero watermark)
    try {
      const neuralVoiceMap: Record<string, string> = {
        M1: 'en_us_006',
        Atlas: 'en_us_010',
        F1: 'en_us_001',
      };
      const selectedNeuralVoice = neuralVoiceMap[voice] || 'en_us_006';
      const neuralBuffers: Buffer[] = [];
      let neuralOk = true;

      for (const chunk of chunks) {
        const ttRes = await fetch('https://tiktok-tts.weilnet.workers.dev/api/generation', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: chunk, voice: selectedNeuralVoice }),
        });
        if (!ttRes.ok) {
          neuralOk = false;
          break;
        }
        const ttJson: any = await ttRes.json().catch(() => null);
        if (ttJson && ttJson.success && typeof ttJson.data === 'string' && ttJson.data.length > 100) {
          neuralBuffers.push(Buffer.from(ttJson.data, 'base64'));
        } else {
          neuralOk = false;
          break;
        }
      }

      if (neuralOk && neuralBuffers.length > 0) {
        res.setHeader('Content-Type', 'audio/mpeg');
        res.setHeader('Cache-Control', 'public, max-age=86400');
        res.send(Buffer.concat(neuralBuffers));
        return;
      }
    } catch (neuralErr) {
      console.warn('[TTS Tier 1 Fallback]:', neuralErr);
    }

    // Tier 2: Multi-chunk Google Translate TTS (handles any text length reliably)
    const audioChunks: Buffer[] = [];
    for (const chunk of chunks) {
      const ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&tl=${encodeURIComponent(lang)}&client=tw-ob&q=${encodeURIComponent(chunk)}`;
      const ttsResponse = await fetch(ttsUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Referer': 'https://translate.google.com/',
        },
      });

      if (!ttsResponse.ok) {
        res.status(ttsResponse.status).send('TTS service unavailable');
        return;
      }

      const audioBuf = await ttsResponse.arrayBuffer();
      audioChunks.push(Buffer.from(audioBuf));
    }

    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.send(Buffer.concat(audioChunks));
  } catch (err: any) {
    console.error('[TTS Endpoint Error]:', err);
    res.status(500).json({ error: err.message });
  }
});

// 4. Zero-GPU Server-Side MP4 Video Compiler (Static Scene Image locked 1-to-1 with Scene Voice length)
interface VideoJobState {
  dir: string;
  scenes: Array<{
    index: number;
    imagePath: string;
    audioPath?: string;
    clipPath?: string;
    duration: number;
  }>;
  createdAt: number;
}

const activeVideoJobs = new Map<string, VideoJobState>();

app.post('/api/video/init', (_req: Request, res: Response) => {
  try {
    const jobId = `job_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), `yt-mp4-${jobId}-`));
    activeVideoJobs.set(jobId, {
      dir,
      scenes: [],
      createdAt: Date.now(),
    });
    res.json({ jobId });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to init video job' });
  }
});

app.post('/api/video/scene', async (req: Request, res: Response) => {
  try {
    const {
      jobId,
      sceneIndex,
      duration,
      imageBase64,
      audioBase64,
      width = 1920,
      height = 1080,
    } = req.body;
    const job = activeVideoJobs.get(jobId);
    if (!job) {
      res.status(404).json({ error: 'Video compilation job not found' });
      return;
    }

    const idxNum = Number(sceneIndex);
    const padIdx = String(idxNum).padStart(3, '0');
    const sceneDur = Math.max(0.25, Number(duration) || 3.0);
    const targetW = Number(width) === 1080 ? 1080 : 1920;
    const targetH = Number(height) === 1920 ? 1920 : 1080;

    const cleanImgBase64 = String(imageBase64 || '').replace(/^data:image\/\w+;base64,/, '');
    const imgBuffer = Buffer.from(cleanImgBase64, 'base64');
    const imagePath = path.join(job.dir, `scene_${padIdx}.jpg`);
    fs.writeFileSync(imagePath, imgBuffer);

    let audioPath: string | undefined;
    let clipPath: string | undefined;

    if (audioBase64) {
      const cleanAudBase64 = String(audioBase64).replace(/^data:audio\/\w+;base64,/, '');
      const audBuffer = Buffer.from(cleanAudBase64, 'base64');
      audioPath = path.join(job.dir, `scene_${padIdx}.wav`);
      fs.writeFileSync(audioPath, audBuffer);

      clipPath = path.join(job.dir, `clip_${padIdx}.mp4`);
      // Create individual scene MP4: Static image held from start to end of this scene's voiceover
      await execFileAsync('ffmpeg', [
        '-y',
        '-loop', '1',
        '-framerate', '25',
        '-i', imagePath,
        '-i', audioPath,
        '-t', sceneDur.toFixed(4),
        '-vf', `scale=${targetW}:${targetH},format=yuv420p`,
        '-r', '25',
        '-video_track_timescale', '25000',
        '-c:v', 'libx264',
        '-preset', 'ultrafast',
        '-tune', 'stillimage',
        '-crf', '22',
        '-c:a', 'aac',
        '-b:a', '128k',
        '-ar', '44100',
        '-ac', '2',
        '-shortest',
        clipPath,
      ]);
    }

    const existingIdx = job.scenes.findIndex((s) => s.index === idxNum);
    const entry = {
      index: idxNum,
      imagePath,
      audioPath,
      clipPath,
      duration: sceneDur,
    };
    if (existingIdx >= 0) {
      job.scenes[existingIdx] = entry;
    } else {
      job.scenes.push(entry);
    }

    res.json({ ok: true, sceneIndex: idxNum, duration: sceneDur });
  } catch (err: any) {
    console.error('[FFmpeg Scene Encode Error]:', err);
    res.status(500).json({ error: err.message || 'Failed to encode scene clip' });
  }
});

app.post('/api/video/finalize', async (req: Request, res: Response) => {
  const { jobId, audioBase64, width = 1920, height = 1080 } = req.body;
  const job = activeVideoJobs.get(jobId);
  if (!job) {
    res.status(404).json({ error: 'Video compilation job not found' });
    return;
  }

  try {
    // Sort scenes strictly in script flow order (0, 1, 2, ...)
    job.scenes.sort((a, b) => a.index - b.index);
    if (job.scenes.length === 0) {
      throw new Error('No scenes uploaded for video compilation');
    }

    const outputPath = path.join(job.dir, 'compiled_output.mp4');
    const allHaveClips = job.scenes.every((s) => s.clipPath && fs.existsSync(s.clipPath));

    if (allHaveClips) {
      // Combine all individual scene MP4 clips in exact script flow order with stream copy
      let clipsListContent = '';
      for (const sc of job.scenes) {
        const escapedClip = sc.clipPath!.replace(/'/g, "'\\''");
        clipsListContent += `file '${escapedClip}'\n`;
      }
      const clipsListPath = path.join(job.dir, 'clips.txt');
      fs.writeFileSync(clipsListPath, clipsListContent, 'utf8');

      await execFileAsync('ffmpeg', [
        '-y',
        '-f', 'concat',
        '-safe', '0',
        '-i', clipsListPath,
        '-c', 'copy',
        '-movflags', '+faststart',
        outputPath,
      ]);
    } else {
      // Fallback: concat images with master WAV audio
      const cleanAudioBase64 = String(audioBase64 || '').replace(/^data:audio\/\w+;base64,/, '');
      const audioBuffer = Buffer.from(cleanAudioBase64, 'base64');
      const audioPath = path.join(job.dir, 'master_audio.wav');
      fs.writeFileSync(audioPath, audioBuffer);

      let concatContent = '';
      for (const sc of job.scenes) {
        const escapedPath = sc.imagePath.replace(/'/g, "'\\''");
        concatContent += `file '${escapedPath}'\n`;
        concatContent += `duration ${sc.duration.toFixed(6)}\n`;
      }
      const lastScene = job.scenes[job.scenes.length - 1];
      const lastEscaped = lastScene.imagePath.replace(/'/g, "'\\''");
      concatContent += `file '${lastEscaped}'\n`;

      const listPath = path.join(job.dir, 'scenes.txt');
      fs.writeFileSync(listPath, concatContent, 'utf8');

      const targetW = Number(width) === 1080 ? 1080 : 1920;
      const targetH = Number(height) === 1920 ? 1920 : 1080;

      await execFileAsync('ffmpeg', [
        '-y',
        '-f', 'concat',
        '-safe', '0',
        '-i', listPath,
        '-i', audioPath,
        '-vf', `fps=25,scale=${targetW}:${targetH},format=yuv420p`,
        '-c:v', 'libx264',
        '-preset', 'ultrafast',
        '-tune', 'stillimage',
        '-crf', '22',
        '-c:a', 'aac',
        '-b:a', '128k',
        '-movflags', '+faststart',
        '-shortest',
        outputPath,
      ]);
    }

    const mp4Buffer = fs.readFileSync(outputPath);
    res.setHeader('Content-Type', 'video/mp4');
    res.setHeader('Content-Length', String(mp4Buffer.length));
    res.send(mp4Buffer);
  } catch (err: any) {
    console.error('[FFmpeg Compile Error]:', err);
    res.status(500).json({ error: err.message || 'FFmpeg MP4 compilation failed' });
  } finally {
    activeVideoJobs.delete(jobId);
    try {
      fs.rmSync(job.dir, { recursive: true, force: true });
    } catch (_) {}
  }
});

// Setup dev server with Vite or static build in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Studio Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
