import React, { useState, useEffect, useRef } from 'react';
import {
  AspectRatio,
  EngineType,
  StyleMode,
  ArtAtmosphere,
  PlannedScene,
  GeneratedItem,
  SceneAudioData,
  StudioSettings,
  CompiledSceneTimeline,
} from './types';
import {
  getDimensions,
  generateCleanFilename,
  generateSingleImageDirect,
  getStylePromptDescription,
  POLLINATIONS_MODELS,
  verifyPollinationsApiKey,
  resolvePollinationsModel,
  sanitizeApiKey,
} from './utils/imageGenerators';
import { synthesizeAudexumVoice, getAudioContext } from './utils/audio';
import { compileSceneVideo } from './utils/videoCompiler';
import { downloadAllZip, saveItemToDirectory } from './utils/fileSystem';
import { SAMPLES, instantLocalBreakdown, buildMatchedScenePrompt } from './utils/breakdown';
import {
  Settings,
  Folder,
  Download,
  Video,
  Play,
  Pause,
  RefreshCw,
  Trash2,
  Copy,
  Plus,
  Mic,
  Image as ImageIcon,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Info,
  X,
  KeyRound,
  Loader2,
  Layers,
} from 'lucide-react';

export default function App() {
  // State
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [engine, setEngine] = useState<EngineType>('pollinations');
  const [styleMode, setStyleMode] = useState<StyleMode>('stickman');
  const [atmosphere, setAtmosphere] = useState<ArtAtmosphere>('default');
  const [pacingDensity, setPacingDensity] = useState('ultra-granular');
  const [maxScenes, setMaxScenes] = useState('max');

  const [scriptInput, setScriptInput] = useState<string>(SAMPLES.horror);
  const [activeTab, setActiveTab] = useState<'scenes' | 'gallery'>('scenes');

  const [plannedScenes, setPlannedScenes] = useState<PlannedScene[]>([]);
  const [generatedItems, setGeneratedItems] = useState<GeneratedItem[]>([]);
  const [audioMap, setAudioMap] = useState<Record<number, SceneAudioData>>({});

  // Generation & progress state
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [thinkingStatus, setThinkingStatus] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [isGeneratingVoices, setIsGeneratingVoices] = useState<boolean>(false);
  const [isCompilingVideo, setIsCompilingVideo] = useState<boolean>(false);
  const [progressText, setProgressText] = useState<string>('');
  const [progressPercent, setProgressPercent] = useState<number>(0);

  // Audio Playback state
  const [activePlayingIndex, setActivePlayingIndex] = useState<number | null>(null);
  const activeAudioRef = useRef<HTMLAudioElement | null>(null);

  // Modals & Output Folder
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [previewImage, setPreviewImage] = useState<{ url: string; caption: string } | null>(null);
  const [compiledVideo, setCompiledVideo] = useState<{
    blob: Blob;
    url: string;
    duration: number;
    sceneTimelines: CompiledSceneTimeline[];
  } | null>(null);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState<boolean>(false);
  const [videoCurrentTime, setVideoCurrentTime] = useState<number>(0);
  const videoPlayerRef = useRef<HTMLVideoElement | null>(null);
  const [outputDirHandle, setOutputDirHandle] = useState<FileSystemDirectoryHandle | null>(null);

  // Toast
  const [toast, setToast] = useState<{ message: string; type: 'info' | 'success' | 'error' } | null>(null);

  // Settings State
  const [settings, setSettings] = useState<StudioSettings>({
    geminiApiKey: '',
    geminiModel: 'gemini-3.8-flash',
    audexumApiKey: 'sk_live_OE8MgVBuVKeE-FUAxTxWSCC8h-GSi9XcUETVrzDZrVk',
    audexumVoice: 'M1',
    audexumSpeed: 1.05,
    audexumBackend: 'supertonic',
    audexumSteps: 8,
    cloudflareAccountId: 'dbd0a20391adcbe84e29798004818d49',
    cloudflareApiToken: 'cfut_dy0p9TorSeHQHqWepjFNcXaQs7CxKk163mlxOsG14774d808',
    cloudflareWorkerUrl: 'https://fffff.adon61144.workers.dev/api/generate',
    pollinationsAuthMode: 'without-key',
    pollinationsApiKey: '',
    pollinationsModel: 'z-image-turbo',
    cloudflareModel: '@cf/black-forest-labs/flux-1-schnell',
    puterModel: 'flux',
    resolution: 'full-hd',
    autoGenerateVoice: false,
    includeSubtitlesInVideo: false,
    includeSceneBadgesInVideo: false,
  });

  const [isVerifyingPollinationsKey, setIsVerifyingPollinationsKey] = useState(false);
  const [pollinationsKeyStatus, setPollinationsKeyStatus] = useState<{
    tested: boolean;
    valid: boolean;
    message: string;
  } | null>(null);

  const [isTestingVoice, setIsTestingVoice] = useState(false);
  const [voiceTestStatus, setVoiceTestStatus] = useState<string | null>(null);

  const handleTestVoiceSynthesis = async () => {
    if (isTestingVoice) return;
    setIsTestingVoice(true);
    setVoiceTestStatus('Synthesizing sample audio...');
    try {
      const res = await synthesizeAudexumVoice(
        'Hello, welcome to YouTube Script to Vision Studio. Voice synthesis is working smoothly.',
        settings.audexumApiKey,
        settings.audexumVoice,
        settings.audexumSpeed,
        settings.audexumBackend,
        settings.audexumSteps
      );
      setVoiceTestStatus(`✓ Working! (${res.duration.toFixed(1)}s)`);
      const audio = new Audio(res.url);
      audio.play().catch((e) => console.warn('Audio play error:', e));
    } catch (err: any) {
      setVoiceTestStatus(`❌ ${err.message}`);
    } finally {
      setIsTestingVoice(false);
    }
  };

  // Load saved settings on mount & plan initial scenes
  useEffect(() => {
    const saved = localStorage.getItem('yt_studio_settings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.pollinationsModel) {
          parsed.pollinationsModel = resolvePollinationsModel(parsed.pollinationsModel);
        }
        // Sanitize backend so 'default' or invalid strings are never loaded from old storage
        if (
          !parsed.audexumBackend ||
          parsed.audexumBackend === 'default' ||
          !['supertonic', 'kokoro', 'qwen', 'v3'].includes(parsed.audexumBackend)
        ) {
          parsed.audexumBackend = 'supertonic';
        }
        parsed.autoGenerateVoice = false;
        setSettings((prev) => ({ ...prev, ...parsed, autoGenerateVoice: false }));
      } catch (e) {
        console.warn('Error loading settings', e);
      }
    }

    // Auto-populate initial planned scenes from sample script so user has immediate preview
    if (plannedScenes.length === 0) {
      const initialScenes = instantLocalBreakdown(SAMPLES.horror, 'stickman', '16:9');
      setPlannedScenes(initialScenes);
    }
  }, []);

  const handleVerifyPollinationsKey = async (keyToTest?: string) => {
    const targetKey = sanitizeApiKey(keyToTest !== undefined ? keyToTest : settings.pollinationsApiKey);
    if (!targetKey) {
      showToast('Please enter an API Key first', 'error');
      setPollinationsKeyStatus({
        tested: true,
        valid: false,
        message: 'No key provided. Paste key from enter.pollinations.ai/keys',
      });
      return;
    }

    setIsVerifyingPollinationsKey(true);
    try {
      const res = await verifyPollinationsApiKey(targetKey);
      setPollinationsKeyStatus({ tested: true, valid: res.valid, message: res.message });
      if (res.valid) {
        showToast(res.message, 'success');
      } else {
        showToast(res.message, 'error');
      }
    } catch (err: any) {
      setPollinationsKeyStatus({
        tested: true,
        valid: false,
        message: err.message || 'Key verification failed',
      });
      showToast(`Verification error: ${err.message}`, 'error');
    } finally {
      setIsVerifyingPollinationsKey(false);
    }
  };

  const saveSettings = (newSettings: StudioSettings) => {
    setSettings(newSettings);
    localStorage.setItem('yt_studio_settings', JSON.stringify(newSettings));
    showToast('Settings saved successfully!', 'success');
    setIsSettingsOpen(false);
  };

  const showToast = (message: string, type: 'info' | 'success' | 'error' = 'info') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3800);
  };

  // Word count helper
  const wordCount = scriptInput.trim() ? scriptInput.trim().split(/\s+/).filter(Boolean).length : 0;

  // Strict 1-to-1 verification helpers for Voice <-> Scene and Image <-> Scene matching
  const isVoiceMatchedToScene = (
    audioData: SceneAudioData | undefined,
    scene: PlannedScene | undefined
  ): boolean => {
    if (!audioData || !scene || audioData.status !== 'ready') return false;
    if (!audioData.audioBuffer && !audioData.blob && !audioData.url) return false;
    if (audioData.scriptText && audioData.scriptText.trim() !== scene.script_part.trim()) {
      return false;
    }
    return true;
  };

  const isImageMatchedToScene = (
    item: GeneratedItem | undefined,
    scene: PlannedScene | undefined,
    targetStyle: StyleMode
  ): boolean => {
    if (!item || !scene || item.status !== 'ready') return false;
    if (!item.imageBlob && !item.localBlobUrl && !item.imageUrl) return false;
    if (item.scriptPart.trim() !== scene.script_part.trim()) return false;
    if (item.prompt.trim() !== scene.image_prompt.trim()) return false;
    if (item.style !== targetStyle) return false;
    return true;
  };

  // Handle Style Switcher
  const handleStyleChange = (mode: StyleMode) => {
    setStyleMode(mode);
    const nextAtmo = mode === 'stickman' ? 'default' : atmosphere;
    if (mode === 'stickman') {
      setAtmosphere('default');
    }
    // Update existing scene prompts so every image prompt strictly matches its scene voice
    if (plannedScenes.length > 0) {
      setPlannedScenes((prev) =>
        prev.map((sc, idx) => {
          const matched = buildMatchedScenePrompt(sc.script_part, idx, mode, aspectRatio, nextAtmo);
          return {
            ...sc,
            visual_thinking: matched.visual_thinking,
            image_prompt: matched.image_prompt,
          };
        })
      );
      showToast(`Updated all scene prompts to ${mode.toUpperCase()} style!`, 'info');
    }
  };

  // Handle Aspect Ratio
  const handleAspectRatioChange = (ratio: AspectRatio) => {
    setAspectRatio(ratio);
    if (plannedScenes.length > 0) {
      setPlannedScenes((prev) =>
        prev.map((sc, idx) => {
          const matched = buildMatchedScenePrompt(sc.script_part, idx, styleMode, ratio, atmosphere);
          return {
            ...sc,
            visual_thinking: matched.visual_thinking,
            image_prompt: matched.image_prompt,
          };
        })
      );
    }
  };

  // ==================== SCRIPT ANALYSIS VIA GEMINI ====================
  const handleAnalyzeScriptWithGemini = async () => {
    if (!scriptInput.trim()) {
      showToast('Please enter or paste your script first.', 'error');
      return;
    }

    stopAllVoicePlayback();
    setIsAnalyzing(true);
    setThinkingStatus(`Using Google Gemini (${settings.geminiModel}) to design granular ${styleMode} scenes...`);

    try {
      const res = await fetch('/api/gemini/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          script: scriptInput.trim(),
          styleMode,
          aspectRatio,
          pacingDensity,
          maxScenes,
          artAtmosphere: atmosphere,
          model: settings.geminiModel,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({ error: 'Server error' }));
        throw new Error(errData.error || `HTTP ${res.status}`);
      }

      const data = await res.json();
      if (!Array.isArray(data.scenes) || data.scenes.length === 0) {
        throw new Error('Gemini did not return any scene items');
      }

      const normalizedScenes: PlannedScene[] = data.scenes.map((sc: PlannedScene, idx: number) => ({
        ...sc,
        scene_number: idx + 1,
      }));

      setPlannedScenes(normalizedScenes);
      setAudioMap({});
      setGeneratedItems([]);
      setCompiledVideo(null);
      setActiveTab('scenes');
      showToast(`Gemini planned ${normalizedScenes.length} voice-matched scenes!`, 'success');
    } catch (err: any) {
      console.warn('Gemini analyze failed, running instant local breakdown fallback:', err);
      showToast(`Using Instant Voice-Matched Scene Breakdown!`, 'info');
      await handleInstantBreakdown();
    } finally {
      setIsAnalyzing(false);
    }
  };

  // ==================== INSTANT LOCAL MICRO-BREAKDOWN ====================
  const handleInstantBreakdown = async () => {
    if (!scriptInput.trim()) {
      showToast('Please enter a script first.', 'error');
      return;
    }
    stopAllVoicePlayback();
    const scenes = instantLocalBreakdown(scriptInput.trim(), styleMode, aspectRatio, atmosphere);
    setPlannedScenes(scenes);
    setAudioMap({});
    setGeneratedItems([]);
    setCompiledVideo(null);
    setActiveTab('scenes');
    showToast(`Created ${scenes.length} ${styleMode} scenes matched to voice lines!`, 'success');
  };

  // Scene editing helpers (keep plannedScenes, audioMap, and generatedItems 100% aligned)
  const updateScene = (index: number, field: keyof PlannedScene, val: string | number) => {
    setPlannedScenes((prev) => {
      const copy = [...prev];
      if (copy[index]) {
        const updatedScene = { ...copy[index], [field]: val };
        // If narration text changed, auto-sync the image prompt so image & voice stay matched
        if (field === 'script_part') {
          const matched = buildMatchedScenePrompt(
            String(val),
            index,
            styleMode,
            aspectRatio,
            atmosphere
          );
          updatedScene.image_prompt = matched.image_prompt;
          updatedScene.visual_thinking = matched.visual_thinking;
        }
        copy[index] = updatedScene;
      }
      return copy;
    });

    if (field === 'script_part') {
      setAudioMap((prev) => {
        const copy = { ...prev };
        delete copy[index];
        return copy;
      });
    }

    if (field === 'script_part' || field === 'image_prompt') {
      setGeneratedItems((prev) => {
        if (!prev[index]) return prev;
        const copy = [...prev];
        copy[index] = {
          ...copy[index],
          status: 'pending',
          imageUrl: null,
          localBlobUrl: null,
          imageBlob: null,
        };
        return copy;
      });
    }
  };

  const deleteScene = (index: number) => {
    if (plannedScenes.length <= 1) {
      showToast('You must have at least one scene.', 'info');
      return;
    }
    stopAllVoicePlayback();
    const prevLength = plannedScenes.length;

    setPlannedScenes((prev) =>
      prev
        .filter((_, i) => i !== index)
        .map((sc, idx) => ({ ...sc, scene_number: idx + 1 }))
    );

    // Re-index audioMap so remaining scenes stay strictly matched to their exact voiceovers
    setAudioMap((prev) => {
      const next: Record<number, SceneAudioData> = {};
      for (let i = 0; i < prevLength; i++) {
        if (i < index && prev[i]) {
          next[i] = prev[i];
        } else if (i > index && prev[i]) {
          next[i - 1] = prev[i];
        }
      }
      return next;
    });

    // Re-index generatedItems so remaining scenes stay strictly matched to their exact images
    setGeneratedItems((prev) =>
      prev
        .filter((_, i) => i !== index)
        .map((it, idx) => ({
          ...it,
          index: idx,
          sceneNumber: idx + 1,
        }))
    );

    showToast(`Scene ${index + 1} removed and timeline re-synced.`, 'info');
  };

  const duplicateScene = (index: number) => {
    const item = plannedScenes[index];
    if (!item) return;
    stopAllVoicePlayback();
    const prevLength = plannedScenes.length;

    setPlannedScenes((prev) => {
      const next = [...prev];
      next.splice(index + 1, 0, { ...item });
      return next.map((sc, idx) => ({ ...sc, scene_number: idx + 1 }));
    });

    // Shift audioMap keys after `index` so every scene keeps its matching voiceover
    setAudioMap((prev) => {
      const next: Record<number, SceneAudioData> = {};
      for (let i = 0; i < prevLength; i++) {
        if (i <= index && prev[i]) {
          next[i] = prev[i];
          if (i === index) {
            next[index + 1] = { ...prev[i] };
          }
        } else if (i > index && prev[i]) {
          next[i + 1] = prev[i];
        }
      }
      return next;
    });

    // Shift generatedItems so every scene keeps its matching image
    setGeneratedItems((prev) => {
      if (!prev.length) return prev;
      const next = [...prev];
      if (next[index]) {
        next.splice(index + 1, 0, { ...next[index] });
      }
      return next.map((it, idx) => ({
        ...it,
        index: idx,
        sceneNumber: idx + 1,
      }));
    });

    showToast(`Duplicated scene ${index + 1}!`, 'success');
  };

  const addCustomScene = () => {
    const newIdx = plannedScenes.length;
    const defaultScript = 'New scene narration line...';
    const matched = buildMatchedScenePrompt(defaultScript, newIdx, styleMode, aspectRatio, atmosphere);
    const newScene: PlannedScene = {
      scene_number: newIdx + 1,
      script_part: defaultScript,
      visual_thinking: matched.visual_thinking,
      image_prompt: matched.image_prompt,
    };
    setPlannedScenes((prev) => [...prev, newScene]);
    showToast(`Added Scene #${newIdx + 1}!`, 'success');
  };

  // ==================== AUDIO SYNTHESIS & PLAYBACK ====================
  const generateSingleVoice = async (
    index: number,
    sceneOverride?: PlannedScene
  ): Promise<SceneAudioData | null> => {
    const scene = sceneOverride || plannedScenes[index];
    if (!scene || !scene.script_part.trim()) return null;

    setAudioMap((prev) => ({
      ...prev,
      [index]: { status: 'generating', scriptText: scene.script_part.trim() },
    }));

    try {
      const result = await synthesizeAudexumVoice(
        scene.script_part,
        settings.audexumApiKey,
        settings.audexumVoice,
        settings.audexumSpeed,
        settings.audexumBackend,
        settings.audexumSteps
      );

      const audioData: SceneAudioData = {
        status: 'ready',
        blob: result.blob,
        audioBuffer: result.audioBuffer,
        duration: result.duration,
        url: result.url,
        scriptText: scene.script_part.trim(),
      };

      setAudioMap((prev) => ({
        ...prev,
        [index]: audioData,
      }));
      showToast(`Voice ready for Scene ${index + 1} (${result.duration.toFixed(1)}s)`, 'success');
      return audioData;
    } catch (err: any) {
      console.error(`Audio synthesis error for scene ${index + 1}:`, err);
      const errData: SceneAudioData = { status: 'error', error: err.message };
      setAudioMap((prev) => ({
        ...prev,
        [index]: errData,
      }));
      showToast(`Voice synthesis failed for Scene ${index + 1}: ${err.message}`, 'error');
      return null;
    }
  };

  const generateVoicesForScenesList = async (scenesList: PlannedScene[]) => {
    if (isGeneratingVoices || !scenesList.length) return;
    setIsGeneratingVoices(true);
    showToast(`Generating scene-by-scene voiceovers for ${scenesList.length} scenes...`, 'info');

    for (let i = 0; i < scenesList.length; i++) {
      await generateSingleVoice(i, scenesList[i]);
    }

    setIsGeneratingVoices(false);
    showToast(`All ${scenesList.length} scene voiceovers generated successfully!`, 'success');
  };

  const generateAllVoices = async () => {
    if (isGeneratingVoices) return;
    if (!plannedScenes.length) {
      showToast('Please plan scenes first.', 'error');
      return;
    }

    await generateVoicesForScenesList(plannedScenes);
  };

  const [isPlayingAllVoices, setIsPlayingAllVoices] = useState<boolean>(false);
  const isPlayingAllRef = useRef<boolean>(false);

  const stopAllVoicePlayback = () => {
    isPlayingAllRef.current = false;
    setIsPlayingAllVoices(false);
    if (activeAudioRef.current) {
      activeAudioRef.current.pause();
      activeAudioRef.current = null;
    }
    setActivePlayingIndex(null);
  };

  const togglePlayAudio = (index: number) => {
    // If playing, clicking pauses it
    if (activePlayingIndex === index) {
      if (activeAudioRef.current) {
        activeAudioRef.current.pause();
        activeAudioRef.current = null;
      }
      setActivePlayingIndex(null);
      return;
    }

    const audioData = audioMap[index];
    if (!audioData || audioData.status !== 'ready' || !audioData.url) {
      showToast(`Please click "Gen Voice" first to generate voice for Scene ${index + 1}.`, 'info');
      return;
    }

    if (activeAudioRef.current) {
      activeAudioRef.current.pause();
      activeAudioRef.current = null;
      setActivePlayingIndex(null);
    }

    const audio = new Audio(audioData.url);
    activeAudioRef.current = audio;
    setActivePlayingIndex(index);

    audio.play().catch((e) => console.warn('Audio play error:', e));
    audio.onended = () => {
      setActivePlayingIndex(null);
      activeAudioRef.current = null;
    };
  };

  const handlePlayAllVoices = async () => {
    if (isPlayingAllVoices) {
      stopAllVoicePlayback();
      return;
    }

    if (!plannedScenes.length) {
      showToast('Please plan scenes first.', 'error');
      return;
    }

    // Check if any voice is missing
    const hasAnyReady = plannedScenes.some((_, i) => audioMap[i]?.status === 'ready' && audioMap[i]?.url);
    if (!hasAnyReady) {
      showToast('No voices generated yet. Click "Generate Voices" first.', 'info');
      return;
    }

    isPlayingAllRef.current = true;
    setIsPlayingAllVoices(true);
    showToast('Starting script narration playback...', 'info');

    for (let i = 0; i < plannedScenes.length; i++) {
      if (!isPlayingAllRef.current) break;

      const audioData = audioMap[i];
      if (!audioData || audioData.status !== 'ready' || !audioData.url) {
        continue;
      }

      setActivePlayingIndex(i);

      await new Promise<void>((resolve) => {
        if (!audioData?.url) return resolve();
        const audio = new Audio(audioData.url);
        activeAudioRef.current = audio;

        audio.onended = () => {
          activeAudioRef.current = null;
          resolve();
        };

        audio.onerror = () => {
          activeAudioRef.current = null;
          resolve();
        };

        audio.play().catch(() => resolve());
      });
    }

    stopAllVoicePlayback();
  };

  // ==================== BATCH GENERATION (IMAGES + VOICES) ====================
  const handleGenerateAll = async (skipVoices = false) => {
    if (isGenerating || isCompilingVideo) return;
    if (!plannedScenes.length) {
      showToast('No scenes planned yet. Please analyze your script first.', 'error');
      return;
    }

    setIsGenerating(true);
    setActiveTab('gallery');

    const { width, height } = getDimensions(aspectRatio);
    const autoVoice = !skipVoices;
    const engineLabel =
      engine === 'cloudflare'
        ? 'Cloudflare AI (FLUX)'
        : engine === 'pollinations'
        ? settings.pollinationsAuthMode === 'with-key'
          ? 'Pollinations (Pro Key)'
          : 'Pollinations (Free)'
        : 'Puter.js';

    // Initialize gallery items strictly indexed 0..plannedScenes.length - 1
    const initialItems: GeneratedItem[] = plannedScenes.map((scene, idx) => ({
      index: idx,
      sceneNumber: idx + 1,
      scriptPart: scene.script_part,
      prompt: scene.image_prompt,
      style: styleMode,
      engine: engineLabel,
      filename: generateCleanFilename(idx, scene.script_part, 'png'),
      audioFilename: generateCleanFilename(idx, scene.script_part, 'wav'),
      txtFilename: generateCleanFilename(idx, scene.script_part, 'txt'),
      status: 'pending',
      imageUrl: null,
      localBlobUrl: null,
      imageBlob: null,
      errorMsg: null,
    }));

    setGeneratedItems(initialItems);
    const workingAudioMap: Record<number, SceneAudioData> = { ...audioMap };

    let completedImages = 0;

    for (let i = 0; i < initialItems.length; i++) {
      const scene = plannedScenes[i];
      const item = initialItems[i];
      item.status = 'generating';
      setGeneratedItems([...initialItems]);

      const pct = Math.round((i / initialItems.length) * 100);
      setProgressPercent(pct);
      setProgressText(
        `[${item.style.toUpperCase()}] Scene ${i + 1}/${initialItems.length}: Generating Matched 1080p Visual${
          autoVoice ? ' + Voiceover' : ''
        }...`
      );

      // Task 1: Image generation for this exact scene prompt
      const imageTask = generateSingleImageDirect(item.prompt, engine, width, height, {
        pollinationsModel: settings.pollinationsModel,
        pollinationsApiKey: settings.pollinationsApiKey,
        pollinationsAuthMode: settings.pollinationsAuthMode,
        cloudflareWorkerUrl: settings.cloudflareWorkerUrl,
        puterModel: settings.puterModel,
      })
        .then((res) => {
          item.imageUrl = res.url;
          item.localBlobUrl = res.blobUrl;
          item.imageBlob = res.blob;
          item.status = 'ready';
          item.errorMsg = null;
          completedImages++;
        })
        .catch((err) => {
          console.error(`Image generation failed for scene ${i + 1}:`, err);
          item.status = 'error';
          item.errorMsg = err.message || 'Image failed';
        });

      // Task 2: Voiceover generation (strictly check that existing audio matches this scene's script_part)
      const needsVoice = autoVoice && !isVoiceMatchedToScene(workingAudioMap[i], scene);
      const voiceTask = needsVoice
        ? generateSingleVoice(i, scene).then((res) => {
            if (res) workingAudioMap[i] = res;
          })
        : Promise.resolve();

      await Promise.all([imageTask, voiceTask]);

      // Auto-save to directory if chosen
      if (outputDirHandle && (item.status as string) === 'ready') {
        await saveItemToDirectory(outputDirHandle, item, workingAudioMap[i]);
      }

      setGeneratedItems([...initialItems]);
    }

    setProgressPercent(100);
    setProgressText(`Complete: ${completedImages} matched images${autoVoice ? ' & voices' : ''} generated!`);
    setIsGenerating(false);

    showToast(`Batch complete! You can now compile the synchronized 1080p video.`, 'success');
  };

  const regenerateSingleImage = async (index: number): Promise<GeneratedItem | null> => {
    const item = generatedItems[index];
    if (!item) return null;

    const { width, height } = getDimensions(aspectRatio);
    item.status = 'generating';
    setGeneratedItems([...generatedItems]);

    try {
      const res = await generateSingleImageDirect(item.prompt, engine, width, height, {
        pollinationsModel: settings.pollinationsModel,
        pollinationsApiKey: settings.pollinationsApiKey,
        pollinationsAuthMode: settings.pollinationsAuthMode,
        cloudflareWorkerUrl: settings.cloudflareWorkerUrl,
        puterModel: settings.puterModel,
      });
      item.imageUrl = res.url;
      item.localBlobUrl = res.blobUrl;
      item.imageBlob = res.blob;
      item.status = 'ready';
      item.errorMsg = null;
      showToast(`Scene ${index + 1} regenerated!`, 'success');

      if (outputDirHandle) {
        await saveItemToDirectory(outputDirHandle, item, audioMap[index]);
      }
      setGeneratedItems([...generatedItems]);
      return item;
    } catch (err: any) {
      item.status = 'error';
      item.errorMsg = err.message || 'Regen failed';
      showToast(`Regeneration failed: ${err.message}`, 'error');
      setGeneratedItems([...generatedItems]);
      return null;
    }
  };

  // ==================== 1080P VIDEO COMPILER ====================
  const handleCompileVideo = async () => {
    if (isCompilingVideo || isGenerating) return;
    if (!plannedScenes.length) {
      showToast('Please plan scenes first.', 'error');
      return;
    }

    // Unlock AudioContext immediately on user click gesture so it never suspends after Phase 1
    try {
      const ctx = getAudioContext();
      if (ctx.state === 'suspended') {
        ctx.resume().catch(() => {});
      }
    } catch (_) {}

    stopAllVoicePlayback();
    setIsCompilingVideo(true);
    setActiveTab('gallery');
    setProgressPercent(4);
    setProgressText('Phase 1: Verifying 1-to-1 match between each scene image and voice...');

    try {
      const engineLabel =
        engine === 'cloudflare'
          ? 'Cloudflare AI (FLUX)'
          : engine === 'pollinations'
          ? settings.pollinationsAuthMode === 'with-key'
            ? 'Pollinations (Pro Key)'
            : 'Pollinations (Free)'
          : 'Puter.js';

      // 1. Build workingItems strictly aligned 1-to-1 with plannedScenes
      // Only reuse an existing image if its scriptPart, prompt, and style match plannedScenes[idx]
      const workingItems: GeneratedItem[] = plannedScenes.map((scene, idx) => {
        const existing = generatedItems[idx];
        if (isImageMatchedToScene(existing, scene, styleMode)) {
          return {
            ...existing,
            index: idx,
            sceneNumber: idx + 1,
            scriptPart: scene.script_part,
            prompt: scene.image_prompt,
          };
        }
        return {
          index: idx,
          sceneNumber: idx + 1,
          scriptPart: scene.script_part,
          prompt: scene.image_prompt,
          style: styleMode,
          engine: engineLabel,
          filename: generateCleanFilename(idx, scene.script_part, 'png'),
          audioFilename: generateCleanFilename(idx, scene.script_part, 'wav'),
          txtFilename: generateCleanFilename(idx, scene.script_part, 'txt'),
          status: 'pending',
          imageUrl: null,
          localBlobUrl: null,
          imageBlob: null,
          errorMsg: null,
        };
      });
      setGeneratedItems([...workingItems]);

      // Build workingAudioMap strictly aligned 1-to-1 with plannedScenes
      const workingAudioMap: Record<number, SceneAudioData> = {};
      plannedScenes.forEach((scene, idx) => {
        if (isVoiceMatchedToScene(audioMap[idx], scene)) {
          workingAudioMap[idx] = audioMap[idx];
        }
      });

      // 2. Ensure EVERY scene has its exact matching voiceover AND its exact matching 1080p image
      const { width, height } = getDimensions(aspectRatio);

      for (let i = 0; i < plannedScenes.length; i++) {
        const scene = plannedScenes[i];
        const pct = Math.round(5 + (i / plannedScenes.length) * 32);
        setProgressPercent(pct);

        // Verify or synthesize voice for Scene i
        if (!isVoiceMatchedToScene(workingAudioMap[i], scene)) {
          setProgressText(
            `🎙️ Synthesizing voice for Scene ${i + 1}/${plannedScenes.length} ("${scene.script_part.slice(0, 28)}...")...`
          );
          const audioResult = await generateSingleVoice(i, scene);
          if (audioResult) {
            workingAudioMap[i] = audioResult;
          }
        }

        // Verify or generate 1080p image for Scene i
        const currentItem = workingItems[i];
        if (
          !currentItem ||
          currentItem.status !== 'ready' ||
          (!currentItem.imageBlob && !currentItem.localBlobUrl && !currentItem.imageUrl)
        ) {
          currentItem.status = 'generating';
          setGeneratedItems([...workingItems]);
          setProgressText(
            `🎨 Generating matched 1080p image for Scene ${i + 1}/${plannedScenes.length} ("${scene.script_part.slice(0, 28)}...")...`
          );

          try {
            const imgRes = await generateSingleImageDirect(
              scene.image_prompt,
              engine,
              width,
              height,
              {
                pollinationsModel: settings.pollinationsModel,
                pollinationsApiKey: settings.pollinationsApiKey,
                pollinationsAuthMode: settings.pollinationsAuthMode,
                cloudflareWorkerUrl: settings.cloudflareWorkerUrl,
                puterModel: settings.puterModel,
              }
            );
            workingItems[i].imageUrl = imgRes.url;
            workingItems[i].localBlobUrl = imgRes.blobUrl;
            workingItems[i].imageBlob = imgRes.blob;
            workingItems[i].status = 'ready';
            workingItems[i].errorMsg = null;
          } catch (e: any) {
            console.error(`Visual generation failed for Scene ${i + 1}:`, e);
            workingItems[i].status = 'error';
            workingItems[i].errorMsg = e.message || 'Image failed';
          }
          setGeneratedItems([...workingItems]);
        }
      }

      setGeneratedItems([...workingItems]);
      setAudioMap({ ...workingAudioMap });

      // 3. Compile video: Lock each scene's static image 1-to-1 with its voiceover duration and combine in script flow into MP4
      setProgressPercent(38);
      setProgressText('Phase 2: Combining each scene static image + voice length in script flow into MP4...');

      const result = await compileSceneVideo(
        workingItems,
        workingAudioMap,
        aspectRatio,
        (pct, status) => {
          setProgressPercent(pct);
          setProgressText(status);
        },
        {
          includeSubtitles: settings.includeSubtitlesInVideo,
          includeBadges: settings.includeSceneBadgesInVideo,
          crossfadeDuration: 0.0,
        }
      );

      setCompiledVideo({
        blob: result.blob,
        url: result.url,
        duration: result.totalDuration,
        sceneTimelines: result.sceneTimelines,
      });
      setVideoCurrentTime(0);

      setIsVideoModalOpen(true);
      showToast(
        `MP4 video ready! All ${workingItems.length} scenes combined in script flow (${result.totalDuration.toFixed(1)}s).`,
        'success'
      );
    } catch (err: any) {
      console.error('Video compilation failed:', err);
      showToast(`Video rendering failed: ${err.message}`, 'error');
    } finally {
      setIsCompilingVideo(false);
    }
  };

  // ==================== FILE EXPORT & FOLDER PICKER ====================
  const handleSelectFolder = async () => {
    if (!('showDirectoryPicker' in window)) {
      showToast('Folder Auto-Save is supported in Chrome, Edge, and Opera browsers.', 'info');
      return;
    }
    try {
      const handle = await (window as any).showDirectoryPicker({ mode: 'readwrite' });
      setOutputDirHandle(handle);
      showToast(`Selected "${handle.name}". Future generations will auto-save here!`, 'success');
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        showToast('Could not select folder: ' + err.message, 'error');
      }
    }
  };

  const handleDownloadAllZip = async () => {
    const readyItems = generatedItems.filter((i) => i.status === 'ready');
    if (!readyItems.length) {
      showToast('No generated scene items ready to download.', 'error');
      return;
    }
    try {
      showToast('Packing all 1080p images, voiceovers, prompts and video into ZIP...', 'info');
      await downloadAllZip(readyItems, audioMap, compiledVideo?.blob || null, aspectRatio);
      showToast('ZIP bundle downloaded successfully!', 'success');
    } catch (err: any) {
      showToast('ZIP failed: ' + err.message, 'error');
    }
  };

  const handleDownloadSingleImage = (index: number) => {
    const item = generatedItems[index];
    if (!item || !item.localBlobUrl) return;
    const a = document.createElement('a');
    a.href = item.localBlobUrl;
    a.download = item.filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast(`Downloaded ${item.filename}`, 'success');
  };

  const handleDownloadSingleAudio = (index: number) => {
    const audio = audioMap[index];
    if (!audio || !audio.url) return;
    const item = generatedItems[index];
    const scriptText = item?.scriptPart || plannedScenes[index]?.script_part || 'scene';
    const filename = generateCleanFilename(index, scriptText, 'wav');
    const a = document.createElement('a');
    a.href = audio.url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast(`Downloaded ${filename}`, 'success');
  };

  return (
    <div className="w-full min-h-screen bg-[#090d12] text-[#f8fafc]">
      <div className="max-w-[1560px] mx-auto px-4 py-6 md:py-8">
        {/* TOP NAVIGATION HEADER */}
        <header className="flex flex-wrap items-center justify-between gap-4 pb-5 mb-6 border-b border-[#1e293b]">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#ff4757] to-[#ff793f] flex items-center justify-center text-2xl shadow-[0_4px_18px_rgba(255,71,87,0.35)]">
              🎬
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-black tracking-tight flex items-center gap-2">
                YT Script-to-Vision AI
                <span className="text-[11px] font-bold bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 px-2 py-0.5 rounded-full uppercase tracking-wider">
                  100% Free / No API Key
                </span>
              </h1>
              <p className="text-xs md:text-sm text-[#94a3b8]">
                Ultra-granular scene breakdown: Stickman, Cartoon & Realistic image generation
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="inline-flex items-center gap-2 px-3.5 py-2 bg-[#111720] border border-[#1e293b] hover:border-[#3b4d63] hover:bg-[#192330] rounded-xl text-xs font-semibold text-[#f8fafc] transition-all cursor-pointer"
            >
              <Settings className="w-4 h-4 text-[#94a3b8]" />
              Settings & Keys
            </button>

            <button
              onClick={handleSelectFolder}
              className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer border ${
                outputDirHandle
                  ? 'border-[#06b6d4] text-[#06b6d4] bg-[#06b6d4]/10'
                  : 'bg-[#111720] border-[#1e293b] hover:border-[#3b4d63] hover:bg-[#192330] text-[#f8fafc]'
              }`}
            >
              <Folder className="w-4 h-4" />
              {outputDirHandle ? `Auto-Saving: ${outputDirHandle.name}` : 'Select Auto-Save Folder'}
            </button>

            {generatedItems.some((i) => i.status === 'ready') && (
              <button
                onClick={handleDownloadAllZip}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#ff4757] to-[#e84118] hover:brightness-110 shadow-[0_4px_14px_rgba(255,71,87,0.35)] transition-all cursor-pointer"
              >
                <Download className="w-4 h-4" />
                Download All (ZIP)
              </button>
            )}

            {compiledVideo && (
              <button
                onClick={() => setIsVideoModalOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#a855f7] to-[#ec4899] hover:brightness-110 shadow-[0_4px_14px_rgba(168,85,247,0.35)] transition-all cursor-pointer"
              >
                <Video className="w-4 h-4" />
                Watch 1080p Video (.mp4)
              </button>
            )}
          </div>
        </header>

        {/* MAIN STUDIO LAYOUT: LEFT SIDEBAR + RIGHT WORKSPACE */}
        <div className="grid grid-cols-1 lg:grid-cols-[460px_1fr] gap-6 items-start">
          {/* LEFT COLUMN: SCRIPT INPUT & CONFIGURATION */}
          <div className="bg-[#111720] border border-[#1e293b] rounded-2xl p-5 md:p-6 shadow-xl space-y-5">
            <div className="flex items-center gap-2.5 pb-2 border-b border-[#1e293b]/70">
              <span className="w-6 h-6 rounded-lg bg-[#ff4757]/15 text-[#ff4757] font-black text-xs flex items-center justify-center">
                1
              </span>
              <h2 className="text-base font-bold text-white">Script & Visual Setup</h2>
            </div>

            {/* GENERATOR ENGINE SWITCHER */}
            <div className="space-y-2.5">
              <div className="flex justify-between items-center text-xs font-semibold text-[#94a3b8]">
                <span>Image Generation Engine</span>
                <span className="text-[11px] font-bold">
                  {engine === 'pollinations' ? (
                    settings.pollinationsAuthMode === 'with-key' ? (
                      <span className="text-[#c084fc]">⚡ Pollinations (With API Key)</span>
                    ) : (
                      <span className="text-[#10b981]">⚡ Pollinations (Without API Key • Free)</span>
                    )
                  ) : engine === 'cloudflare' ? (
                    <span className="text-[#f97316]">Cloudflare Workers AI (FLUX)</span>
                  ) : (
                    <span className="text-[#f59e0b]">Puter.js (Multi-Model)</span>
                  )}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2 bg-[#0b1118] p-1.5 rounded-xl border border-[#1e293b]">
                <button
                  type="button"
                  onClick={() => setEngine('pollinations')}
                  className={`py-2 px-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    engine === 'pollinations'
                      ? 'border border-[#06b6d4] text-[#06b6d4] bg-[#06b6d4]/15 shadow-sm'
                      : 'text-[#94a3b8] hover:text-white'
                  }`}
                >
                  ⚡ Pollinations
                </button>
                <button
                  type="button"
                  onClick={() => setEngine('cloudflare')}
                  className={`py-2 px-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    engine === 'cloudflare'
                      ? 'border border-[#f97316] text-[#f97316] bg-[#f97316]/15 shadow-sm'
                      : 'text-[#94a3b8] hover:text-white'
                  }`}
                >
                  ☁️ Cloudflare AI
                </button>
                <button
                  type="button"
                  onClick={() => setEngine('puter')}
                  className={`py-2 px-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    engine === 'puter'
                      ? 'border border-[#f59e0b] text-[#f59e0b] bg-[#f59e0b]/15 shadow-sm'
                      : 'text-[#94a3b8] hover:text-white'
                  }`}
                >
                  🎨 Puter.js
                </button>
              </div>

              {/* POLLINATIONS TWO OPTIONS: WITHOUT API KEY vs WITH API KEY */}
              {engine === 'pollinations' && (
                <div className="p-3 bg-[#0b1118] border border-[#06b6d4]/30 rounded-xl space-y-2.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-white flex items-center gap-1.5">
                      <span className="text-[#06b6d4]">⚡</span> Pollinations Access Mode
                    </span>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded font-semibold border ${
                        settings.pollinationsAuthMode === 'without-key'
                          ? 'bg-[#10b981]/15 text-[#10b981] border-[#10b981]/30'
                          : 'bg-[#a855f7]/15 text-[#c084fc] border-[#a855f7]/30'
                      }`}
                    >
                      {settings.pollinationsAuthMode === 'without-key' ? 'Option 1: Free (No Key)' : 'Option 2: Pro (With Key)'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const updated = { ...settings, pollinationsAuthMode: 'without-key' as const };
                        setSettings(updated);
                        localStorage.setItem('yt_studio_settings', JSON.stringify(updated));
                        showToast('Switched to Pollinations Free (Without API Key)', 'info');
                      }}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        settings.pollinationsAuthMode === 'without-key'
                          ? 'border-[#10b981] bg-[#10b981]/15 ring-1 ring-[#10b981]/50'
                          : 'border-[#1e293b] bg-[#111720] hover:border-[#334155]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="text-xs font-bold text-[#f8fafc]">Without API Key</span>
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-[#10b981]/20 text-[#10b981]">100% Free</span>
                      </div>
                      <div className="text-[10px] text-[#94a3b8] leading-tight">
                        Instant generation. No API key, token, or account needed.
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const updated = { ...settings, pollinationsAuthMode: 'with-key' as const };
                        setSettings(updated);
                        localStorage.setItem('yt_studio_settings', JSON.stringify(updated));
                        showToast('Switched to Pollinations Pro (With API Key)', 'info');
                      }}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        settings.pollinationsAuthMode === 'with-key'
                          ? 'border-[#a855f7] bg-[#a855f7]/15 ring-1 ring-[#a855f7]/50'
                          : 'border-[#1e293b] bg-[#111720] hover:border-[#334155]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="text-xs font-bold text-[#f8fafc]">With API Key</span>
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-[#a855f7]/20 text-[#c084fc]">Pro / BYOK</span>
                      </div>
                      <div className="text-[10px] text-[#94a3b8] leading-tight">
                        Fast dedicated queue, Pro models, and zero rate limits.
                      </div>
                    </button>
                  </div>

                  {settings.pollinationsAuthMode === 'with-key' && (
                    <div className="pt-2 border-t border-[#1e293b] space-y-2">
                      <div className="flex justify-between items-center text-[11px]">
                        <label className="text-[#c084fc] font-semibold flex items-center gap-1">
                          <KeyRound className="w-3.5 h-3.5 text-[#c084fc]" />
                          Pollinations API Key
                        </label>
                        <a
                          href="https://enter.pollinations.ai/keys"
                          target="_blank"
                          rel="noreferrer"
                          className="text-[10px] text-[#38bdf8] hover:underline inline-flex items-center gap-1"
                        >
                          enter.pollinations.ai/keys ↗
                        </a>
                      </div>
                      <div className="flex gap-1.5">
                        <input
                          type="password"
                          value={settings.pollinationsApiKey}
                          onChange={(e) => {
                            const updated = { ...settings, pollinationsApiKey: e.target.value };
                            setSettings(updated);
                            localStorage.setItem('yt_studio_settings', JSON.stringify(updated));
                            setPollinationsKeyStatus(null);
                          }}
                          placeholder="Paste sk_... or pk_..."
                          className="flex-1 bg-[#111720] border border-[#a855f7]/40 rounded-lg px-2.5 py-1.5 text-xs text-[#f8fafc] focus:outline-none focus:border-[#a855f7]"
                        />
                        <button
                          type="button"
                          onClick={() => handleVerifyPollinationsKey()}
                          disabled={isVerifyingPollinationsKey || !settings.pollinationsApiKey.trim()}
                          className="px-2.5 py-1.5 rounded-lg text-[11px] font-bold bg-[#a855f7]/20 border border-[#a855f7]/50 text-[#c084fc] hover:bg-[#a855f7]/30 disabled:opacity-40 transition-all flex items-center gap-1 shrink-0 cursor-pointer"
                        >
                          {isVerifyingPollinationsKey ? (
                            <>
                              <Loader2 className="w-3 h-3 animate-spin" />
                              Testing...
                            </>
                          ) : (
                            <>⚡ Test Key</>
                          )}
                        </button>
                      </div>

                      {/* Live verification status indicator */}
                      {pollinationsKeyStatus && (
                        <div
                          className={`text-[10px] p-2 rounded-lg border flex items-start gap-1.5 ${
                            pollinationsKeyStatus.valid
                              ? 'bg-[#10b981]/10 border-[#10b981]/30 text-[#6ee7b7]'
                              : 'bg-[#ef4444]/10 border-[#ef4444]/30 text-[#fca5a5]'
                          }`}
                        >
                          {pollinationsKeyStatus.valid ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-[#10b981] shrink-0 mt-0.5" />
                          ) : (
                            <AlertTriangle className="w-3.5 h-3.5 text-[#ef4444] shrink-0 mt-0.5" />
                          )}
                          <span className="leading-snug">{pollinationsKeyStatus.message}</span>
                        </div>
                      )}

                      <p className="text-[10px] text-[#94a3b8] leading-tight">
                        Uses official gateway <code>gen.pollinations.ai</code> with Bearer auth &amp; auto-fallback on error.
                      </p>
                    </div>
                  )}

                  {/* Pollinations Model Selection */}
                  <div className="pt-2 border-t border-[#1e293b]">
                    <div className="flex justify-between items-center text-[11px] mb-1">
                      <span className="text-[#94a3b8] font-semibold">Pollinations Model</span>
                      <span className="text-[10px] font-mono text-[#06b6d4]">
                        {settings.pollinationsModel}
                      </span>
                    </div>
                    <select
                      value={settings.pollinationsModel}
                      onChange={(e) => {
                        const updated = {
                          ...settings,
                          pollinationsModel: resolvePollinationsModel(e.target.value),
                        };
                        setSettings(updated);
                        localStorage.setItem('yt_studio_settings', JSON.stringify(updated));
                      }}
                      className="w-full bg-[#111720] border border-[#1e293b] rounded-lg p-2 text-xs text-[#f8fafc] focus:outline-none focus:border-[#06b6d4]"
                    >
                      {POLLINATIONS_MODELS.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.label} {m.pro ? '⚡ (Pro Key)' : '✨ (Fast/Free)'}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              )}
            </div>

            {/* VISUAL CHARACTER STYLE: Stickman vs Cartoon vs Realistic */}
            <div>
              <div className="flex justify-between items-center text-xs font-semibold text-[#94a3b8] mb-2">
                <span>Visual Character Style</span>
                <span className="text-[11px] text-[#64748b]">Stickman • Cartoon • Realistic</span>
              </div>
              <div className="grid grid-cols-3 gap-2.5">
                <button
                  type="button"
                  onClick={() => handleStyleChange('stickman')}
                  className={`p-3 rounded-xl text-center border-2 transition-all flex flex-col items-center gap-1 cursor-pointer ${
                    styleMode === 'stickman'
                      ? 'border-[#38bdf8] bg-[#38bdf8]/12 shadow-[0_4px_14px_rgba(56,189,248,0.25)]'
                      : 'border-[#1e293b] bg-[#0b1118] hover:border-[#3b5066]'
                  }`}
                >
                  <span className="text-2xl">✏️</span>
                  <div className="font-extrabold text-xs text-[#38bdf8]">Stickman</div>
                  <div className="text-[10px] text-[#64748b] leading-tight">Soft Gray BG, Doodle</div>
                </button>

                <button
                  type="button"
                  onClick={() => handleStyleChange('cartoon')}
                  className={`p-3 rounded-xl text-center border-2 transition-all flex flex-col items-center gap-1 cursor-pointer ${
                    styleMode === 'cartoon'
                      ? 'border-[#f59e0b] bg-[#f59e0b]/12 shadow-[0_4px_14px_rgba(245,158,11,0.25)]'
                      : 'border-[#1e293b] bg-[#0b1118] hover:border-[#3b5066]'
                  }`}
                >
                  <span className="text-2xl">🎨</span>
                  <div className="font-extrabold text-xs text-[#f59e0b]">Cartoon</div>
                  <div className="text-[10px] text-[#64748b] leading-tight">2D/3D Pixar Style</div>
                </button>

                <button
                  type="button"
                  onClick={() => handleStyleChange('realistic')}
                  className={`p-3 rounded-xl text-center border-2 transition-all flex flex-col items-center gap-1 cursor-pointer ${
                    styleMode === 'realistic'
                      ? 'border-[#ff4757] bg-[#ff4757]/12 shadow-[0_4px_14px_rgba(255,71,87,0.35)]'
                      : 'border-[#1e293b] bg-[#0b1118] hover:border-[#3b5066]'
                  }`}
                >
                  <span className="text-2xl">📸</span>
                  <div className="font-extrabold text-xs text-[#ff6b81]">Realistic</div>
                  <div className="text-[10px] text-[#64748b] leading-tight">8k Photorealistic</div>
                </button>
              </div>
            </div>

            {/* STYLE NOTICE BANNER */}
            <div className="bg-[#10b981]/10 border border-[#10b981]/25 rounded-xl p-2.5 text-xs text-[#6ee7b7] flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-[#10b981]" />
              <span>
                <strong>Engine:</strong>{' '}
                {engine === 'pollinations'
                  ? settings.pollinationsAuthMode === 'with-key'
                    ? 'Pollinations AI (With API Key)'
                    : 'Pollinations AI (Without API Key • Free)'
                  : engine}{' '}
                renders <strong>{styleMode.toUpperCase()}</strong> with clean, fixed {aspectRatio} aesthetics!
              </span>
            </div>

            {/* SCRIPT NARRATION INPUT */}
            <div>
              <div className="flex justify-between items-center text-xs font-semibold text-[#94a3b8] mb-1.5">
                <span>YouTube Video Script</span>
                <span className="text-[11px] text-[#64748b] font-mono">{wordCount} words</span>
              </div>
              <textarea
                rows={7}
                value={scriptInput}
                onChange={(e) => setScriptInput(e.target.value)}
                placeholder="Paste your YouTube video narration script here..."
                className="w-full bg-[#0b1118] border border-[#1e293b] rounded-xl p-3 text-sm text-[#f8fafc] focus:outline-none focus:border-[#ff4757] focus:ring-2 focus:ring-[#ff4757]/20 resize-y leading-relaxed font-sans"
              />

              {/* Sample script pills */}
              <div className="flex flex-wrap items-center gap-1.5 mt-2">
                <span className="text-[11px] text-[#64748b] mr-1">Try:</span>
                <button
                  type="button"
                  onClick={() => setScriptInput(SAMPLES.horror)}
                  className="px-2.5 py-1 bg-[#182230] border border-[#283747] hover:border-[#06b6d4] hover:text-[#06b6d4] rounded-lg text-[11px] text-[#94a3b8] transition-all cursor-pointer"
                >
                  👻 Horror Story
                </button>
                <button
                  type="button"
                  onClick={() => setScriptInput(SAMPLES.space)}
                  className="px-2.5 py-1 bg-[#182230] border border-[#283747] hover:border-[#06b6d4] hover:text-[#06b6d4] rounded-lg text-[11px] text-[#94a3b8] transition-all cursor-pointer"
                >
                  🚀 Space Mystery
                </button>
                <button
                  type="button"
                  onClick={() => setScriptInput(SAMPLES.stoic)}
                  className="px-2.5 py-1 bg-[#182230] border border-[#283747] hover:border-[#06b6d4] hover:text-[#06b6d4] rounded-lg text-[11px] text-[#94a3b8] transition-all cursor-pointer"
                >
                  🏛️ Stoic Wisdom
                </button>
                <button
                  type="button"
                  onClick={() => setScriptInput(SAMPLES.tech)}
                  className="px-2.5 py-1 bg-[#182230] border border-[#283747] hover:border-[#06b6d4] hover:text-[#06b6d4] rounded-lg text-[11px] text-[#94a3b8] transition-all cursor-pointer"
                >
                  🤖 Future AI City
                </button>
              </div>
            </div>

            {/* FIXED ASPECT RATIO (16:9 vs 9:16) */}
            <div>
              <div className="flex justify-between items-center text-xs font-semibold text-[#94a3b8] mb-1.5">
                <span className="flex items-center gap-1.5">
                  <span>Image Fixed Size Format</span>
                  <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30">
                    Always Fixed
                  </span>
                </span>
                <span className="text-[11px] text-[#64748b]">Choose 16:9 or 9:16</span>
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => handleAspectRatioChange('16:9')}
                  className={`p-3 rounded-xl border flex items-center gap-3 transition-all cursor-pointer ${
                    aspectRatio === '16:9'
                      ? 'border-[#ff4757] bg-[#ff4757]/10 ring-1 ring-[#ff4757]/50 shadow-sm'
                      : 'border-[#1e293b] bg-[#0b1118] hover:border-[#3b4d63]'
                  }`}
                >
                  <div
                    className={`w-9 h-5 rounded border flex items-center justify-center text-[10px] font-bold ${
                      aspectRatio === '16:9' ? 'border-[#ff4757] text-[#ff4757]' : 'border-[#64748b] text-[#64748b]'
                    }`}
                  >
                    16:9
                  </div>
                  <div className="text-left">
                    <div className="text-xs font-bold text-white flex items-center gap-1">
                      16:9 Landscape
                      {aspectRatio === '16:9' && <span className="w-1.5 h-1.5 rounded-full bg-[#ff4757]"></span>}
                    </div>
                    <div className="text-[10px] text-[#64748b] font-mono">Fixed: 1920 × 1080</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => handleAspectRatioChange('9:16')}
                  className={`p-3 rounded-xl border flex items-center gap-3 transition-all cursor-pointer ${
                    aspectRatio === '9:16'
                      ? 'border-[#ff4757] bg-[#ff4757]/10 ring-1 ring-[#ff4757]/50 shadow-sm'
                      : 'border-[#1e293b] bg-[#0b1118] hover:border-[#3b4d63]'
                  }`}
                >
                  <div
                    className={`w-5 h-8 rounded border flex items-center justify-center text-[10px] font-bold ${
                      aspectRatio === '9:16' ? 'border-[#ff4757] text-[#ff4757]' : 'border-[#64748b] text-[#64748b]'
                    }`}
                  >
                    9:16
                  </div>
                  <div className="text-left">
                    <div className="text-xs font-bold text-white flex items-center gap-1">
                      9:16 Shorts / Reels
                      {aspectRatio === '9:16' && <span className="w-1.5 h-1.5 rounded-full bg-[#ff4757]"></span>}
                    </div>
                    <div className="text-[10px] text-[#64748b] font-mono">Fixed: 1080 × 1920</div>
                  </div>
                </button>
              </div>
            </div>

            {/* MODEL SELECT & ATMOSPHERE */}
            <div className="grid grid-cols-2 gap-3">
              {engine === 'pollinations' && (
                <div>
                  <label className="block text-xs font-semibold text-[#94a3b8] mb-1">Pollinations Model</label>
                  <select
                    value={settings.pollinationsModel}
                    onChange={(e) => {
                      const updated = {
                        ...settings,
                        pollinationsModel: resolvePollinationsModel(e.target.value),
                      };
                      setSettings(updated);
                      localStorage.setItem('yt_studio_settings', JSON.stringify(updated));
                    }}
                    className="w-full bg-[#0b1118] border border-[#1e293b] rounded-xl p-2.5 text-xs text-[#f8fafc] focus:outline-none focus:border-[#ff4757]"
                  >
                    {POLLINATIONS_MODELS.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.label} {m.pro ? '⭐' : ''}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {engine === 'cloudflare' && (
                <div>
                  <label className="block text-xs font-semibold text-[#94a3b8] mb-1">Cloudflare Model</label>
                  <select
                    value={settings.cloudflareModel}
                    onChange={(e) => setSettings({ ...settings, cloudflareModel: e.target.value })}
                    className="w-full bg-[#0b1118] border border-[#1e293b] rounded-xl p-2.5 text-xs text-[#f8fafc] focus:outline-none focus:border-[#ff4757]"
                  >
                    <option value="@cf/black-forest-labs/flux-1-schnell">⚡ FLUX.1 Schnell</option>
                    <option value="@cf/stabilityai/stable-diffusion-xl-base-1.0">🎨 SDXL Base 1.0</option>
                    <option value="@cf/bytedance/stable-diffusion-xl-lightning">⚡ SDXL Lightning</option>
                  </select>
                </div>
              )}

              {engine === 'puter' && (
                <div>
                  <label className="block text-xs font-semibold text-[#94a3b8] mb-1">Puter Model</label>
                  <select
                    value={settings.puterModel}
                    onChange={(e) => setSettings({ ...settings, puterModel: e.target.value })}
                    className="w-full bg-[#0b1118] border border-[#1e293b] rounded-xl p-2.5 text-xs text-[#f8fafc] focus:outline-none focus:border-[#ff4757]"
                  >
                    <option value="flux">FLUX (Recommended)</option>
                    <option value="nano-banana">Nano Banana</option>
                    <option value="gpt-image-1">GPT Image 1</option>
                    <option value="grok-image">Grok Image</option>
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-[#94a3b8] mb-1">Mood / Atmosphere</label>
                <select
                  value={atmosphere}
                  disabled={styleMode === 'stickman'}
                  onChange={(e) => setAtmosphere(e.target.value as ArtAtmosphere)}
                  className="w-full bg-[#0b1118] border border-[#1e293b] rounded-xl p-2.5 text-xs text-[#f8fafc] focus:outline-none focus:border-[#ff4757] disabled:opacity-50"
                >
                  <option value="default">Standard Balanced</option>
                  <option value="dark-thriller">🌑 Dark Mystery & Suspense</option>
                  <option value="humorous-fun">😂 Humorous & Playful</option>
                  <option value="dramatic-epic">🔥 Dramatic & Epic</option>
                  <option value="educational-clean">📘 Clean Explainer</option>
                </select>
              </div>
            </div>

            {/* PACING & SCENE DENSITY */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#94a3b8] mb-1">Scene Granularity</label>
                <select
                  value={pacingDensity}
                  onChange={(e) => setPacingDensity(e.target.value)}
                  className="w-full bg-[#0b1118] border border-[#1e293b] rounded-xl p-2.5 text-xs text-[#f8fafc] focus:outline-none focus:border-[#ff4757]"
                >
                  <option value="ultra-granular">🔥 Ultra Granular (Every 2-3s)</option>
                  <option value="fast">⚡ Fast (Every 3-5s)</option>
                  <option value="balanced">⏱️ Balanced (Every 6-8s)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#94a3b8] mb-1">Target Scene Count</label>
                <select
                  value={maxScenes}
                  onChange={(e) => setMaxScenes(e.target.value)}
                  className="w-full bg-[#0b1118] border border-[#1e293b] rounded-xl p-2.5 text-xs text-[#f8fafc] focus:outline-none focus:border-[#ff4757]"
                >
                  <option value="max">🔥 Maximum (Every micro beat)</option>
                  <option value="8">At least 8 Scenes</option>
                  <option value="12">At least 12 Scenes</option>
                  <option value="16">At least 16 Scenes</option>
                  <option value="20">20+ Scenes</option>
                </select>
              </div>
            </div>

            {/* AUDEXUM VOICE TTS SETTINGS */}
            <div className="bg-[#a855f7]/10 border border-[#a855f7]/25 rounded-xl p-3.5 space-y-2.5">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-[#a855f7] flex items-center gap-1.5">
                  <Mic className="w-3.5 h-3.5" /> Audexum Voiceover TTS
                </span>
                <span className="text-[10px] text-[#ec4899] font-mono">Active Key Loaded</span>
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] text-[#94a3b8] mb-1">Voice Persona</label>
                  <select
                    value={settings.audexumVoice}
                    onChange={(e) => setSettings({ ...settings, audexumVoice: e.target.value })}
                    className="w-full bg-[#0b1118] border border-[#1e293b] rounded-lg p-2 text-xs text-[#f8fafc]"
                  >
                    <option value="M1">🎙️ M1 (Natural Male)</option>
                    <option value="F1">🎙️ F1 (Natural Female)</option>
                    <option value="Atlas">🌟 Atlas (V3 Ultra)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-[#94a3b8] mb-1">Narration Speed</label>
                  <select
                    value={settings.audexumSpeed}
                    onChange={(e) => setSettings({ ...settings, audexumSpeed: parseFloat(e.target.value) })}
                    className="w-full bg-[#0b1118] border border-[#1e293b] rounded-lg p-2 text-xs text-[#f8fafc]"
                  >
                    <option value={0.95}>0.95x (Deliberate)</option>
                    <option value={1.0}>1.0x (Standard)</option>
                    <option value={1.05}>1.05x (YouTube Paced)</option>
                    <option value={1.15}>1.15x (Fast Shorts)</option>
                  </select>
                </div>
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-[#c084fc] bg-[#a855f7]/10 px-2.5 py-1.5 rounded-lg border border-[#a855f7]/20">
                <Mic className="w-3.5 h-3.5 shrink-0 text-[#a855f7]" />
                <span>Voice generation is on-demand (generate individually or via "Generate Voices").</span>
              </div>
            </div>

            {/* ACTION BUTTONS */}
            <div className="flex flex-col gap-2.5 pt-1">
              <button
                type="button"
                disabled={isAnalyzing || isGeneratingVoices}
                onClick={handleAnalyzeScriptWithGemini}
                className="w-full py-3.5 px-4 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-[#0284c7] to-[#06b6d4] hover:brightness-110 shadow-[0_4px_16px_rgba(6,182,212,0.3)] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4" />
                <span>
                  {isAnalyzing
                    ? 'Planning scenes with Gemini...'
                    : '⚡ Plan Scenes (Gemini AI)'}
                </span>
              </button>

              <button
                type="button"
                disabled={isAnalyzing || isGeneratingVoices}
                onClick={handleInstantBreakdown}
                className="w-full py-2.5 px-3 rounded-xl text-xs font-semibold text-[#06b6d4] border border-[#1e3a47] bg-[#111720] hover:bg-[#16222f] transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>🚀 Instant Local Scene Breakdown</span>
              </button>

              {plannedScenes.length > 0 && (
                <button
                  type="button"
                  disabled={isGeneratingVoices}
                  onClick={generateAllVoices}
                  className="w-full py-2.5 px-3 rounded-xl text-xs font-bold text-[#c084fc] border border-[#a855f7]/40 bg-[#a855f7]/10 hover:bg-[#a855f7]/20 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Mic className="w-3.5 h-3.5" />
                  <span>
                    {isGeneratingVoices
                      ? 'Generating Voiceovers...'
                      : `🎙️ Voiceover All Scenes (${plannedScenes.length})`}
                  </span>
                </button>
              )}
            </div>

            <p className="text-[11px] text-[#64748b] text-center">
              Google Gemini 3.8 Flash for director planning & Pollinations AI (Z-Image Turbo) for 100% free image generation
            </p>
          </div>

          {/* RIGHT COLUMN: STUDIO WORKSPACE (SCENES & GALLERY) */}
          <div className="flex flex-col gap-5">
            {/* WORKSPACE TABS & BATCH ACTION BUTTONS */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#1e293b]">
              <div className="flex items-center gap-2 bg-[#0b1118] p-1 rounded-xl border border-[#1e293b]">
                <button
                  type="button"
                  onClick={() => setActiveTab('scenes')}
                  className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeTab === 'scenes'
                      ? 'bg-[#17212e] text-white border border-[#2b394b] shadow-sm'
                      : 'text-[#94a3b8] hover:text-white'
                  }`}
                >
                  📝 Planned Scenes ({plannedScenes.length})
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('gallery')}
                  className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeTab === 'gallery'
                      ? 'bg-[#17212e] text-white border border-[#2b394b] shadow-sm'
                      : 'text-[#94a3b8] hover:text-white'
                  }`}
                >
                  🖼️ Image Studio ({generatedItems.length})
                </button>
              </div>

              {plannedScenes.length > 0 && (
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={addCustomScene}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#111720] border border-[#1e293b] hover:border-[#3b4d63] rounded-lg text-xs font-semibold text-[#f8fafc] cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add Scene
                  </button>

                  <button
                    onClick={handlePlayAllVoices}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                      isPlayingAllVoices
                        ? 'bg-[#ef4444] text-white animate-pulse'
                        : 'bg-[#111720] border border-[#a855f7]/40 hover:bg-[#a855f7]/15 text-[#d8b4fe]'
                    }`}
                  >
                    {isPlayingAllVoices ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                    <span>{isPlayingAllVoices ? 'Stop Narration' : '▶ Play Full Narration'}</span>
                  </button>

                  <button
                    disabled={isGeneratingVoices}
                    onClick={generateAllVoices}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#111720] border border-[#a855f7]/40 hover:bg-[#a855f7]/10 rounded-lg text-xs font-semibold text-[#a855f7] cursor-pointer disabled:opacity-50"
                  >
                    <Mic className="w-3.5 h-3.5" /> Generate Voices
                  </button>

                  <button
                    disabled={isGenerating || isCompilingVideo}
                    onClick={() => handleGenerateAll(true)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#111720] border border-[#10b981]/40 hover:bg-[#10b981]/10 rounded-lg text-xs font-semibold text-[#10b981] cursor-pointer disabled:opacity-50"
                  >
                    <ImageIcon className="w-3.5 h-3.5" /> Images Only
                  </button>

                  <button
                    disabled={isGenerating || isCompilingVideo}
                    onClick={() => handleGenerateAll(false)}
                    className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-bold text-white bg-gradient-to-r from-[#ff4757] to-[#e84118] hover:brightness-110 shadow-sm cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className="w-3.5 h-3.5" /> Generate Both
                  </button>

                  <button
                    disabled={isCompilingVideo || isGenerating || isGeneratingVoices}
                    onClick={handleCompileVideo}
                    className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-bold text-white bg-gradient-to-r from-[#a855f7] to-[#ec4899] hover:brightness-110 shadow-sm cursor-pointer disabled:opacity-50"
                  >
                    <Video className="w-3.5 h-3.5" /> {isCompilingVideo ? 'Compiling MP4...' : 'Export 1080p MP4 Video'}
                  </button>
                </div>
              )}
            </div>

            {/* EMPTY STATE */}
            {plannedScenes.length === 0 && !isAnalyzing && (
              <div className="bg-[#111720] border border-dashed border-[#1e293b] rounded-2xl p-12 md:p-16 text-center">
                <div className="text-5xl mb-3">🎬</div>
                <h3 className="text-lg font-bold text-white mb-2">No Scenes Planned Yet</h3>
                <p className="text-xs md:text-sm text-[#94a3b8] max-w-lg mx-auto mb-6">
                  Paste your YouTube script on the left, select <strong>Stickman</strong>,{' '}
                  <strong>Cartoon</strong>, or <strong>Realistic</strong>, and click{' '}
                  <strong>"Plan Micro-Scenes"</strong>. The AI will divide your script into granular beats with
                  tailored prompts!
                </p>
                <div className="flex justify-center gap-3 flex-wrap">
                  <button
                    onClick={handleAnalyzeScriptWithGemini}
                    className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#0284c7] to-[#06b6d4] hover:brightness-110 shadow-md cursor-pointer"
                  >
                    ⚡ Plan Micro-Scenes with Gemini
                  </button>
                  <button
                    onClick={handleInstantBreakdown}
                    className="px-5 py-2.5 rounded-xl text-xs font-semibold text-[#f8fafc] bg-[#17212e] border border-[#2b394b] hover:bg-[#202c3c] cursor-pointer"
                  >
                    🚀 Instant Micro-Breakdown
                  </button>
                </div>
              </div>
            )}

            {/* GEMINI THINKING STATE */}
            {isAnalyzing && (
              <div className="bg-[#06b6d4]/5 border border-[#06b6d4]/30 rounded-2xl p-12 text-center">
                <div className="media-spinner mx-auto mb-4 border-t-[#06b6d4]"></div>
                <h3 className="text-base font-bold text-[#06b6d4] mb-1">
                  Gemini AI is Creating Granular Micro-Scenes...
                </h3>
                <p className="text-xs text-[#94a3b8]">{thinkingStatus}</p>
              </div>
            )}

            {/* TAB 1: PLANNED SCENES VIEW */}
            {activeTab === 'scenes' && plannedScenes.length > 0 && (
              <div className="space-y-3.5">
                {plannedScenes.map((scene, idx) => {
                  const audioData = audioMap[idx];
                  const hasAudio = audioData && audioData.status === 'ready';
                  const isAudioGenerating = audioData && audioData.status === 'generating';
                  const isPlaying = activePlayingIndex === idx;

                  return (
                    <div
                      key={idx}
                      className={`rounded-xl p-4 transition-all border ${
                        isPlaying
                          ? 'bg-[#151122] border-[#a855f7] ring-1 ring-[#a855f7]/60 shadow-[0_0_20px_rgba(168,85,247,0.18)]'
                          : 'bg-[#111720] border-[#1e293b] hover:border-[#2e3e52]'
                      }`}
                    >
                      <div className="flex justify-between items-center mb-2.5">
                        <span className="inline-flex items-center gap-1.5 text-xs font-bold font-mono text-[#f59e0b] bg-[#f59e0b]/10 border border-[#f59e0b]/20 px-2.5 py-1 rounded-md">
                          🎬 SCENE {String(scene.scene_number || idx + 1).padStart(2, '0')}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <button
                            title="Duplicate Scene"
                            onClick={() => duplicateScene(idx)}
                            className="w-7 h-7 rounded-md bg-[#16202c] border border-[#263647] hover:bg-[#223042] flex items-center justify-center text-[#94a3b8] hover:text-white cursor-pointer"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                          <button
                            title="Delete Scene"
                            onClick={() => deleteScene(idx)}
                            className="w-7 h-7 rounded-md bg-[#16202c] border border-[#263647] hover:bg-[#451a1e] hover:border-[#842029] flex items-center justify-center text-[#94a3b8] hover:text-[#fca5a5] cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-[#64748b] mb-1">
                            Script Narration Part (Voice & Scene Text)
                          </label>
                          <textarea
                            rows={3}
                            value={scene.script_part}
                            onChange={(e) => updateScene(idx, 'script_part', e.target.value)}
                            className="w-full bg-[#0b1118] border border-[#1e293b] rounded-lg p-2.5 text-xs text-[#f8fafc] focus:outline-none focus:border-[#ff4757] resize-y"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-[#64748b] mb-1">
                            Image Prompt ({styleMode.toUpperCase()} - {aspectRatio})
                          </label>
                          <textarea
                            rows={3}
                            value={scene.image_prompt}
                            onChange={(e) => updateScene(idx, 'image_prompt', e.target.value)}
                            className="w-full bg-[#0b1118] border border-[#1e293b] rounded-lg p-2.5 text-xs text-[#f8fafc] focus:outline-none focus:border-[#ff4757] resize-y"
                          />
                        </div>
                      </div>

                      {/* Scene Voice Audio Bar */}
                      <div className="flex items-center gap-2.5 p-2 bg-[#a855f7]/10 border border-[#a855f7]/20 rounded-lg flex-wrap">
                        {/* Play Voice button (active when voice has been generated) */}
                        <button
                          disabled={!hasAudio || isAudioGenerating}
                          onClick={() => togglePlayAudio(idx)}
                          className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#1e172e] border border-[#582b8c] hover:border-[#a855f7] rounded-md text-xs font-bold text-[#e9d5ff] cursor-pointer disabled:opacity-40 transition-colors"
                          title={hasAudio ? 'Listen to scene voiceover' : 'Generate voice first using Gen Voice button'}
                        >
                          {isPlaying ? (
                            <Pause className="w-3 h-3 text-[#f43f5e]" />
                          ) : (
                            <Play className="w-3 h-3 text-[#a855f7]" />
                          )}
                          <span>{isPlaying ? 'Pause' : 'Play Voice'}</span>
                        </button>

                        <span className="text-[11px] font-bold font-mono text-[#d8b4fe] bg-[#a855f7]/20 px-2 py-0.5 rounded">
                          {hasAudio
                            ? `⏱️ ${audioData.duration?.toFixed(1)}s`
                            : isAudioGenerating
                            ? '⏳ Synthesizing...'
                            : '⏱️ Not Generated'}
                        </span>

                        {/* Explicit Click to Generate Voice */}
                        <button
                          disabled={isAudioGenerating}
                          onClick={() => generateSingleVoice(idx)}
                          className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#2e1065] border border-[#a855f7] hover:bg-[#3b0764] rounded-md text-xs font-bold text-[#f3e8ff] cursor-pointer disabled:opacity-50 transition-colors shadow-sm"
                        >
                          <RefreshCw className={`w-3 h-3 ${isAudioGenerating ? 'animate-spin' : ''}`} />
                          <span>{isAudioGenerating ? 'Generating...' : hasAudio ? 'Re-Gen Voice' : '🎙️ Gen Voice'}</span>
                        </button>

                        <span
                          className={`text-[11px] font-semibold ml-auto ${
                            hasAudio
                              ? 'text-[#10b981]'
                              : isAudioGenerating
                              ? 'text-[#f59e0b] animate-pulse-subtle'
                              : 'text-[#94a3b8]'
                          }`}
                        >
                          {hasAudio
                            ? `✓ Voice Ready (${audioData.duration?.toFixed(1)}s)`
                            : isAudioGenerating
                            ? 'Synthesizing voice...'
                            : 'Click "Gen Voice" to generate'}
                        </span>
                      </div>

                      {scene.visual_thinking && (
                        <div className="text-xs text-[#06b6d4] bg-[#06b6d4]/10 border-l-2 border-[#06b6d4] p-2 rounded-r-md mt-2">
                          💡 <strong>Visual Beat:</strong> {scene.visual_thinking}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {/* TAB 2: IMAGE GENERATION & GALLERY VIEW */}
            {activeTab === 'gallery' && (
              <div className="space-y-4">
                {/* Live Progress Bar */}
                {(isGenerating || isCompilingVideo || progressPercent > 0) && (
                  <div className="bg-[#111720] border border-[#1e293b] rounded-xl p-4 space-y-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-[#94a3b8]">
                        Status: <strong className="text-[#f59e0b]">{progressText}</strong>
                      </span>
                      <span className="font-mono font-bold text-white">{progressPercent}%</span>
                    </div>
                    <div className="w-full h-2 bg-[#0b1118] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-[#ff4757] to-[#ff9f43] rounded-full transition-all duration-300"
                        style={{ width: `${progressPercent}%` }}
                      />
                    </div>
                  </div>
                )}

                {/* Generated Items Grid */}
                {generatedItems.length === 0 && !isGenerating && (
                  <div className="bg-[#111720] border border-dashed border-[#1e293b] rounded-2xl p-10 text-center text-[#94a3b8]">
                    <ImageIcon className="w-12 h-12 mx-auto mb-2 text-[#64748b]" />
                    <h4 className="text-sm font-bold text-white mb-1">No Images Rendered Yet</h4>
                    <p className="text-xs text-[#64748b] max-w-md mx-auto mb-4">
                      Click <strong>"Generate Both (Images + Voice)"</strong> or{' '}
                      <strong>"Images Only"</strong> to begin generating all scene visuals.
                    </p>
                    <button
                      onClick={() => handleGenerateAll(false)}
                      className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#ff4757] to-[#e84118] hover:brightness-110 shadow-sm cursor-pointer"
                    >
                      ✨ Generate All Scene Images & Voices
                    </button>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                  {generatedItems.map((item, idx) => {
                    const audioData = audioMap[idx];
                    const hasAudio = audioData && audioData.status === 'ready';
                    const isAudioGenerating = audioData && audioData.status === 'generating';
                    const isPlaying = activePlayingIndex === idx;
                    const displayUrl = item.localBlobUrl || item.imageUrl;

                    return (
                      <div
                        key={idx}
                        className="bg-[#111720] border border-[#1e293b] hover:border-[#3b4d63] rounded-xl overflow-hidden flex flex-col transition-all shadow-md group"
                      >
                        {/* Media Box */}
                        <div
                          className={`relative bg-[#090e14] flex items-center justify-center overflow-hidden ${
                            aspectRatio === '9:16' ? 'aspect-[9/16] max-h-[480px]' : 'aspect-video'
                          }`}
                        >
                          {item.status === 'ready' && displayUrl ? (
                            <>
                              <img
                                src={displayUrl}
                                alt={item.filename}
                                onClick={() => setPreviewImage({ url: displayUrl, caption: item.filename })}
                                className="w-full h-full object-cover cursor-pointer group-hover:scale-[1.02] transition-transform duration-300"
                              />
                              <span className="absolute top-2.5 left-2.5 bg-black/70 backdrop-blur-md border border-white/15 px-2 py-0.5 rounded text-[11px] font-bold font-mono text-white">
                                #{String(item.sceneNumber).padStart(2, '0')}
                              </span>
                              <span className="absolute bottom-2.5 left-2.5 bg-black/70 backdrop-blur-md border border-white/15 px-2 py-0.5 rounded text-[10px] font-semibold text-[#06b6d4]">
                                {item.style.toUpperCase()} • {item.engine}
                              </span>
                              <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#10b981]/90 text-white backdrop-blur-md shadow-sm">
                                ✓ {aspectRatio === '16:9' ? '1920×1080 (16:9)' : '1080×1920 (9:16)'}
                              </span>
                              {hasAudio && (
                                <span className="absolute bottom-2.5 right-2.5 bg-black/75 backdrop-blur-md border border-[#a855f7]/40 text-[#e9d5ff] rounded px-2 py-0.5 text-[10px] font-mono font-bold flex items-center gap-1">
                                  🎙️ {audioData.duration?.toFixed(1)}s
                                </span>
                              )}
                            </>
                          ) : item.status === 'generating' ? (
                            <div className="flex flex-col items-center gap-2.5 text-xs text-[#94a3b8] p-4 text-center">
                              <div className="media-spinner"></div>
                              <span>Rendering {item.style} visual...</span>
                            </div>
                          ) : item.status === 'error' ? (
                            <div className="flex flex-col items-center gap-2 text-xs text-[#fca5a5] p-4 text-center">
                              <AlertTriangle className="w-8 h-8 text-[#ef4444]" />
                              <span>{item.errorMsg || 'Failed'}</span>
                            </div>
                          ) : (
                            <div className="flex flex-col items-center gap-2 text-xs text-[#64748b] p-4 text-center">
                              <span className="text-2xl">⏳</span>
                              <span>Queued for generation</span>
                            </div>
                          )}
                        </div>

                        {/* Scene audio strip */}
                        <div className="flex items-center gap-2 p-2 bg-[#0f172a]/70 border-t border-b border-[#1e293b] text-xs flex-wrap">
                          <button
                            disabled={!hasAudio || isAudioGenerating}
                            onClick={() => togglePlayAudio(idx)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#1e172e] border border-[#582b8c] hover:border-[#a855f7] rounded text-[11px] font-bold text-[#e9d5ff] cursor-pointer transition-colors disabled:opacity-40"
                          >
                            {isPlaying ? (
                              <Pause className="w-3 h-3 text-[#f43f5e]" />
                            ) : (
                              <Play className="w-3 h-3 text-[#a855f7]" />
                            )}
                            <span>{isPlaying ? 'Pause' : 'Play Voice'}</span>
                          </button>

                          <span className="text-[10px] font-mono text-[#d8b4fe] bg-[#a855f7]/20 px-1.5 py-0.5 rounded">
                            {hasAudio
                              ? `${audioData.duration?.toFixed(1)}s`
                              : isAudioGenerating
                              ? '⏳ Gen...'
                              : 'No Voice'}
                          </span>

                          <button
                            disabled={isAudioGenerating}
                            onClick={() => generateSingleVoice(idx)}
                            className="ml-auto inline-flex items-center gap-1 px-2 py-0.5 bg-[#2e1065] border border-[#a855f7] hover:bg-[#3b0764] rounded text-[11px] font-bold text-[#f3e8ff] cursor-pointer disabled:opacity-50 transition-colors"
                          >
                            <RefreshCw className={`w-2.5 h-2.5 ${isAudioGenerating ? 'animate-spin' : ''}`} />
                            <span>{isAudioGenerating ? 'Generating...' : hasAudio ? 'Re-Gen' : '🎙️ Gen Voice'}</span>
                          </button>
                        </div>

                        {/* Card Content */}
                        <div className="p-3 flex flex-col flex-1 gap-2">
                          <div className="font-mono text-[11px] text-[#f59e0b] bg-[#f59e0b]/10 border border-[#f59e0b]/20 px-2 py-1 rounded truncate">
                            📄 {item.filename}
                          </div>

                          <div className="text-xs text-[#f8fafc] font-medium line-clamp-2">
                            "{item.scriptPart}"
                          </div>

                          <div className="text-[11px] text-[#64748b] line-clamp-2">{item.prompt}</div>

                          <div className="flex items-center gap-2 pt-2 mt-auto border-t border-[#1e293b]">
                            <button
                              disabled={item.status === 'generating'}
                              onClick={() => regenerateSingleImage(idx)}
                              className="flex-1 py-1.5 px-2 bg-[#17212e] border border-[#2a3b4e] hover:bg-[#243448] rounded-lg text-xs font-semibold text-[#f8fafc] flex items-center justify-center gap-1 cursor-pointer disabled:opacity-40"
                            >
                              <RefreshCw className="w-3 h-3" /> 1080p Image
                            </button>

                            <button
                              disabled={item.status !== 'ready'}
                              onClick={() => handleDownloadSingleImage(idx)}
                              className="py-1.5 px-3 bg-[#17212e] border border-[#2a3b4e] hover:border-[#10b981] hover:text-[#10b981] rounded-lg text-xs font-semibold text-[#f8fafc] flex items-center justify-center gap-1 cursor-pointer disabled:opacity-40"
                            >
                              <Download className="w-3 h-3" /> PNG
                            </button>

                            {hasAudio && (
                              <button
                                onClick={() => handleDownloadSingleAudio(idx)}
                                className="py-1.5 px-2.5 bg-[#17212e] border border-[#2a3b4e] hover:border-[#a855f7] hover:text-[#a855f7] rounded-lg text-xs font-semibold text-[#f8fafc] flex items-center justify-center gap-1 cursor-pointer"
                                title="Download trimmed WAV voiceover"
                              >
                                WAV
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* SETTINGS MODAL */}
      {isSettingsOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#111720] border border-[#1e293b] rounded-2xl max-w-xl w-full p-6 max-h-[90vh] overflow-y-auto shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-[#1e293b]">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Settings className="w-5 h-5 text-[#ff4757]" /> Studio Configuration & API Keys
              </h3>
              <button
                onClick={() => setIsSettingsOpen(false)}
                className="text-[#94a3b8] hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Pollinations Notice */}
            <div className="bg-[#10b981]/10 border border-[#10b981]/25 rounded-xl p-3 text-xs text-[#6ee7b7]">
              <div className="font-bold flex items-center gap-1.5 mb-1 text-[#10b981]">
                <span>🚀</span> Pollinations AI: 100% Free (No API Key Required)
              </div>
              Pollinations AI generates images completely free without any API key or login! Default model is{' '}
              <strong>Z-Image Turbo</strong>.
            </div>

            {/* Audexum Voice Settings */}
            <div className="bg-[#a855f7]/10 border border-[#a855f7]/25 rounded-xl p-3 space-y-2.5">
              <div className="flex justify-between items-center text-xs font-bold text-[#a855f7]">
                <span>🎙️ Audexum Text-to-Speech API</span>
                <span className="text-[#10b981] font-mono text-[10px]">● Connected</span>
              </div>
              <div>
                <label className="block text-[11px] text-[#94a3b8] mb-1">Audexum API Key (Bearer)</label>
                <input
                  type="text"
                  value={settings.audexumApiKey}
                  onChange={(e) => setSettings({ ...settings, audexumApiKey: e.target.value })}
                  placeholder="sk_live_..."
                  className="w-full bg-[#0b1118] border border-[#1e293b] rounded-lg p-2 text-xs text-[#f8fafc]"
                />
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] text-[#94a3b8] mb-1">TTS Backend</label>
                  <select
                    value={settings.audexumBackend}
                    onChange={(e) => setSettings({ ...settings, audexumBackend: e.target.value })}
                    className="w-full bg-[#0b1118] border border-[#1e293b] rounded-lg p-2 text-xs text-[#f8fafc]"
                  >
                    <option value="supertonic">Supertonic (Fast & Natural)</option>
                    <option value="v3">V3 Ultra (Expressive)</option>
                    <option value="kokoro">Kokoro (Clear Explainer)</option>
                    <option value="qwen">Qwen (High Fidelity)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-[#94a3b8] mb-1">Inference Steps</label>
                  <select
                    value={settings.audexumSteps}
                    onChange={(e) => setSettings({ ...settings, audexumSteps: parseInt(e.target.value, 10) })}
                    className="w-full bg-[#0b1118] border border-[#1e293b] rounded-lg p-2 text-xs text-[#f8fafc]"
                  >
                    <option value={4}>4 (Fastest)</option>
                    <option value={8}>8 (Balanced Quality)</option>
                    <option value={12}>12 (Highest Detail)</option>
                  </select>
                </div>
              </div>

              {/* Test Voice Button */}
              <div className="pt-2 border-t border-[#a855f7]/20 flex items-center justify-between gap-2">
                <button
                  type="button"
                  disabled={isTestingVoice}
                  onClick={handleTestVoiceSynthesis}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#a855f7]/20 hover:bg-[#a855f7]/30 border border-[#a855f7]/40 rounded-lg text-xs font-bold text-[#e9d5ff] cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3 h-3 ${isTestingVoice ? 'animate-spin' : ''}`} />
                  <span>{isTestingVoice ? 'Testing Voice...' : '🔊 Test Voice Synthesis'}</span>
                </button>
                {voiceTestStatus && (
                  <span className={`text-[11px] font-medium ${voiceTestStatus.startsWith('✓') ? 'text-[#10b981]' : voiceTestStatus.startsWith('❌') ? 'text-[#ff4757]' : 'text-[#f59e0b]'}`}>
                    {voiceTestStatus}
                  </span>
                )}
              </div>
            </div>

            {/* Pollinations AI Settings */}
            <div className="p-3 bg-[#0b1118] border border-[#06b6d4]/30 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span className="text-[#06b6d4]">⚡</span> Pollinations AI Engine Options
                </span>
                <span className="text-[10px] font-mono text-[#06b6d4] bg-[#06b6d4]/15 px-2 py-0.5 rounded border border-[#06b6d4]/30">
                  Two Access Modes
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setSettings({ ...settings, pollinationsAuthMode: 'without-key' })}
                  className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                    settings.pollinationsAuthMode === 'without-key'
                      ? 'border-[#10b981] bg-[#10b981]/15 ring-1 ring-[#10b981]/40'
                      : 'border-[#1e293b] bg-[#111720]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-xs font-bold text-white">Without API Key</span>
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-[#10b981]/20 text-[#10b981]">100% Free</span>
                  </div>
                  <p className="text-[10px] text-[#94a3b8]">Free public community pool. Zero setup.</p>
                </button>

                <button
                  type="button"
                  onClick={() => setSettings({ ...settings, pollinationsAuthMode: 'with-key' })}
                  className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                    settings.pollinationsAuthMode === 'with-key'
                      ? 'border-[#a855f7] bg-[#a855f7]/15 ring-1 ring-[#a855f7]/40'
                      : 'border-[#1e293b] bg-[#111720]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-xs font-bold text-white">With API Key</span>
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-[#a855f7]/20 text-[#c084fc]">Pro / BYOK</span>
                  </div>
                  <p className="text-[10px] text-[#94a3b8]">Priority queue &amp; access to Pro models.</p>
                </button>
              </div>

              {settings.pollinationsAuthMode === 'with-key' && (
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-[11px]">
                    <label className="text-[#c084fc] font-semibold flex items-center gap-1">
                      <KeyRound className="w-3.5 h-3.5 text-[#c084fc]" />
                      Pollinations API Key
                    </label>
                    <a
                      href="https://enter.pollinations.ai/keys"
                      target="_blank"
                      rel="noreferrer"
                      className="text-[10px] text-[#38bdf8] hover:underline"
                    >
                      enter.pollinations.ai/keys ↗
                    </a>
                  </div>
                  <div className="flex gap-1.5">
                    <input
                      type="password"
                      value={settings.pollinationsApiKey}
                      onChange={(e) => {
                        setSettings({ ...settings, pollinationsApiKey: e.target.value });
                        setPollinationsKeyStatus(null);
                      }}
                      placeholder="Paste sk_... or pk_..."
                      className="flex-1 bg-[#111720] border border-[#a855f7]/40 rounded-lg px-2.5 py-1.5 text-xs text-[#f8fafc] focus:outline-none focus:border-[#a855f7]"
                    />
                    <button
                      type="button"
                      onClick={() => handleVerifyPollinationsKey()}
                      disabled={isVerifyingPollinationsKey || !settings.pollinationsApiKey.trim()}
                      className="px-3 py-1.5 rounded-lg text-xs font-bold bg-[#a855f7]/20 border border-[#a855f7]/50 text-[#c084fc] hover:bg-[#a855f7]/30 disabled:opacity-40 transition-all flex items-center gap-1 shrink-0 cursor-pointer"
                    >
                      {isVerifyingPollinationsKey ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          Testing...
                        </>
                      ) : (
                        <>⚡ Test Key</>
                      )}
                    </button>
                  </div>

                  {pollinationsKeyStatus && (
                    <div
                      className={`text-[10px] p-2 rounded-lg border flex items-start gap-1.5 ${
                        pollinationsKeyStatus.valid
                          ? 'bg-[#10b981]/10 border-[#10b981]/30 text-[#6ee7b7]'
                          : 'bg-[#ef4444]/10 border-[#ef4444]/30 text-[#fca5a5]'
                      }`}
                    >
                      {pollinationsKeyStatus.valid ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#10b981] shrink-0 mt-0.5" />
                      ) : (
                        <AlertTriangle className="w-3.5 h-3.5 text-[#ef4444] shrink-0 mt-0.5" />
                      )}
                      <span className="leading-snug">{pollinationsKeyStatus.message}</span>
                    </div>
                  )}

                  <p className="text-[10px] text-[#94a3b8] leading-tight">
                    Validated against <code>gen.pollinations.ai</code> with Bearer auth and automatic fallback.
                  </p>
                </div>
              )}

              <div>
                <label className="block text-[11px] text-[#94a3b8] mb-1">Pollinations AI Model</label>
                <select
                  value={settings.pollinationsModel}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      pollinationsModel: resolvePollinationsModel(e.target.value),
                    })
                  }
                  className="w-full bg-[#111720] border border-[#1e293b] rounded-lg p-2 text-xs text-[#f8fafc] focus:outline-none focus:border-[#06b6d4]"
                >
                  {POLLINATIONS_MODELS.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.label} {m.pro ? '⚡ (Pro Key)' : '✨ (Fast/Free)'}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Cloudflare Worker URL */}

            <div>
              <label className="block text-xs font-semibold text-[#94a3b8] mb-1">
                Cloudflare Worker URL for Image Generation
              </label>
              <input
                type="text"
                value={settings.cloudflareWorkerUrl}
                onChange={(e) => setSettings({ ...settings, cloudflareWorkerUrl: e.target.value })}
                className="w-full bg-[#0b1118] border border-[#1e293b] rounded-xl p-2.5 text-xs text-[#f8fafc]"
              />
            </div>

            {/* Fixed Dimensions Specification */}
            <div>
              <label className="block text-xs font-semibold text-[#94a3b8] mb-1">Enforced Fixed Dimensions Standard</label>
              <div className="p-3 bg-[#0b1118] border border-[#1e293b] rounded-xl text-xs space-y-1.5">
                <div className="flex items-center justify-between text-[#f8fafc] font-semibold">
                  <span>Aspect Ratio Standards:</span>
                  <span className="text-[#10b981] font-mono text-[10px] bg-[#10b981]/15 px-2 py-0.5 rounded border border-[#10b981]/30">Strictly Enforced</span>
                </div>
                <div className="text-[#94a3b8] text-[11px] leading-relaxed">
                  • <strong>16:9 Landscape</strong>: Fixed at exactly 1920 × 1080 Full HD (YouTube standard)<br/>
                  • <strong>9:16 Vertical</strong>: Fixed at exactly 1080 × 1920 Full HD (YouTube Shorts / Reels)
                </div>
                <p className="text-[10px] text-[#64748b] pt-1 border-t border-[#1e293b]/70">
                  Every generated visual is normalized on an offscreen canvas to guarantee zero distortion, zero letterboxing, and exact pixel output across all AI engines.
                </p>
              </div>
            </div>

            {/* Video Overlays & Flow Settings */}
            <div className="p-3 bg-[#0b1118] border border-[#1e293b] rounded-xl text-xs space-y-2.5">
              <div className="flex items-center justify-between text-[#f8fafc] font-semibold">
                <span>Clean Video & Cinematic Flow</span>
                <span className="text-[#38bdf8] font-mono text-[10px] bg-[#38bdf8]/15 px-2 py-0.5 rounded border border-[#38bdf8]/30">Active</span>
              </div>
              <div className="space-y-2 pt-1 text-[11px] text-[#94a3b8]">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={settings.includeSubtitlesInVideo}
                    onChange={(e) => setSettings({ ...settings, includeSubtitlesInVideo: e.target.checked })}
                    className="rounded bg-[#17212e] border-[#334155] text-[#ff4757] focus:ring-0 w-3.5 h-3.5"
                  />
                  <span>Burn Subtitles / Captions on video (Default: <strong>Off</strong> for clean visuals)</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={settings.includeSceneBadgesInVideo}
                    onChange={(e) => setSettings({ ...settings, includeSceneBadgesInVideo: e.target.checked })}
                    className="rounded bg-[#17212e] border-[#334155] text-[#ff4757] focus:ring-0 w-3.5 h-3.5"
                  />
                  <span>Show &quot;SCENE 01 / 01&quot; &amp; Timecode badge (Default: <strong>Off</strong> for clean video)</span>
                </label>
              </div>
              <p className="text-[10px] text-[#10b981] pt-1 border-t border-[#1e293b]/70 flex items-center gap-1.5">
                <span>✓</span> <strong>Zero-GPU MP4 Compiler:</strong> Holds each scene&apos;s static image for the exact length of its voiceover and combines all scenes in script flow into <code>.mp4</code>.
              </p>
            </div>


            <div className="flex justify-end gap-2.5 pt-3 border-t border-[#1e293b]">
              <button
                type="button"
                onClick={() => setIsSettingsOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-[#94a3b8] hover:bg-[#17212e] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => saveSettings(settings)}
                className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#ff4757] to-[#e84118] hover:brightness-110 shadow-sm cursor-pointer"
              >
                Save Configuration
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FULLSCREEN IMAGE PREVIEW MODAL */}
      {previewImage && (
        <div
          onClick={() => setPreviewImage(null)}
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col items-center justify-center p-4 cursor-pointer"
        >
          <img
            src={previewImage.url}
            alt={previewImage.caption}
            className="max-w-[92vw] max-h-[82vh] rounded-xl object-contain shadow-2xl"
          />
          <p className="mt-3 text-xs md:text-sm text-white bg-black/70 px-4 py-1.5 rounded-lg border border-white/10">
            {previewImage.caption} (Click anywhere to close)
          </p>
        </div>
      )}

      {/* 1080P VIDEO PREVIEW MODAL */}
      {isVideoModalOpen && compiledVideo && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#111720] border border-[#1e293b] rounded-2xl max-w-5xl w-full p-6 max-h-[92vh] overflow-y-auto shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-[#1e293b]">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Video className="w-5 h-5 text-[#a855f7]" /> 1080p Voice-Matched Scene Video Preview
              </h3>
              <button
                onClick={() => setIsVideoModalOpen(false)}
                className="text-[#94a3b8] hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-black rounded-xl overflow-hidden flex items-center justify-center min-h-[280px] max-h-[55vh]">
              <video
                ref={videoPlayerRef}
                src={compiledVideo.url}
                controls
                autoPlay
                playsInline
                onTimeUpdate={(e) => setVideoCurrentTime(e.currentTarget.currentTime)}
                className="max-w-full max-h-[53vh] rounded-lg"
              />
            </div>

            {/* Interactive Scene-by-Scene Voice & Image Sync Timeline */}
            {compiledVideo.sceneTimelines && compiledVideo.sceneTimelines.length > 0 && (
              <div className="space-y-2 pt-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-[#e2e8f0] flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-[#10b981]" />
                    1-to-1 Scene Image &amp; Voice Synchronization Timeline (Click any scene to jump)
                  </span>
                  <span className="font-mono text-[11px] text-[#a855f7]">
                    {videoCurrentTime.toFixed(1)}s / {compiledVideo.duration.toFixed(1)}s
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 max-h-[190px] overflow-y-auto pr-1">
                  {compiledVideo.sceneTimelines.map((tl) => {
                    const isActive =
                      videoCurrentTime >= tl.start &&
                      (videoCurrentTime < tl.end ||
                        (tl.sceneIndex === compiledVideo.sceneTimelines.length - 1 &&
                          videoCurrentTime <= tl.end + 0.3));
                    return (
                      <button
                        key={tl.sceneIndex}
                        type="button"
                        onClick={() => {
                          if (videoPlayerRef.current) {
                            videoPlayerRef.current.currentTime = tl.start + 0.02;
                            videoPlayerRef.current.play().catch(() => {});
                          }
                        }}
                        className={`flex items-center gap-2.5 p-2 rounded-xl border text-left transition-all cursor-pointer ${
                          isActive
                            ? 'bg-[#a855f7]/20 border-[#a855f7] ring-1 ring-[#a855f7]/60'
                            : 'bg-[#0b1118] border-[#1e293b] hover:border-[#334155]'
                        }`}
                      >
                        <img
                          src={tl.imageUrl}
                          alt={`Scene ${tl.sceneNumber}`}
                          className="w-14 h-10 rounded-lg object-cover shrink-0 border border-white/10"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-1">
                            <span className="text-[10px] font-mono font-bold text-[#f59e0b]">
                              SCENE #{String(tl.sceneNumber).padStart(2, '0')}
                            </span>
                            <span className="text-[10px] font-mono text-[#10b981]">
                              {tl.start.toFixed(1)}s–{tl.end.toFixed(1)}s ({tl.duration.toFixed(1)}s)
                            </span>
                          </div>
                          <div className="text-[11px] text-[#f8fafc] truncate mt-0.5">
                            &ldquo;{tl.scriptPart}&rdquo;
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#1e293b]">
              <div className="text-xs text-[#94a3b8]">
                Resolution:{' '}
                <strong className="text-white">
                  {aspectRatio === '9:16' ? '1080×1920 (9:16 Shorts)' : '1920×1080 (16:9 YouTube HD)'}
                </strong>{' '}
                • Total Duration: <strong className="text-white">{compiledVideo.duration.toFixed(1)}s</strong> • Voice:{' '}
                <strong className="text-[#a855f7]">Audexum {settings.audexumVoice}</strong>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsVideoModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-[#94a3b8] hover:bg-[#17212e] cursor-pointer"
                >
                  Close
                </button>
                <a
                  href={compiledVideo.url}
                  download={
                    aspectRatio === '9:16'
                      ? `youtube_short_1080x1920_${Date.now()}.mp4`
                      : `youtube_video_1920x1080_${Date.now()}.mp4`
                  }
                  className="inline-flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#a855f7] to-[#ec4899] hover:brightness-110 shadow-sm cursor-pointer"
                >
                  <Download className="w-4 h-4" /> Export &amp; Download Video (.mp4)
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TOAST NOTIFICATION */}
      {toast && (
        <div
          className={`fixed bottom-6 right-6 z-50 px-4 py-3 rounded-xl text-xs font-semibold text-white shadow-2xl flex items-center gap-2.5 transition-all animate-bounce ${
            toast.type === 'success'
              ? 'bg-[#10b981] border-l-4 border-[#047857]'
              : toast.type === 'error'
              ? 'bg-[#ff4757] border-l-4 border-[#b91c1c]'
              : 'bg-[#06b6d4] border-l-4 border-[#0e7490]'
          }`}
        >
          {toast.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4" />
          ) : toast.type === 'error' ? (
            <AlertTriangle className="w-4 h-4" />
          ) : (
            <Info className="w-4 h-4" />
          )}
          <span>{toast.message}</span>
        </div>
      )}
    </div>
  );
}
