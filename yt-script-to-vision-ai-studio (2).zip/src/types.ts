export type AspectRatio = '16:9' | '9:16';
export type EngineType = 'pollinations' | 'cloudflare' | 'puter';
export type StyleMode = 'stickman' | 'cartoon' | 'realistic';
export type ArtAtmosphere = 'default' | 'dark-thriller' | 'humorous-fun' | 'dramatic-epic' | 'educational-clean';

export interface PlannedScene {
  scene_number: number;
  script_part: string;
  visual_thinking: string;
  image_prompt: string;
}

export interface SceneAudioData {
  status: 'idle' | 'generating' | 'ready' | 'error';
  blob?: Blob;
  audioBuffer?: AudioBuffer;
  duration?: number;
  url?: string;
  error?: string;
  scriptText?: string;
}

export interface CompiledSceneTimeline {
  sceneIndex: number;
  sceneNumber: number;
  scriptPart: string;
  imageUrl: string;
  start: number;
  end: number;
  duration: number;
}

export interface GeneratedItem {
  index: number;
  sceneNumber: number;
  scriptPart: string;
  prompt: string;
  style: StyleMode;
  engine: string;
  filename: string;
  audioFilename: string;
  txtFilename: string;
  status: 'pending' | 'generating' | 'ready' | 'error';
  imageUrl: string | null;
  localBlobUrl: string | null;
  imageBlob: Blob | null;
  errorMsg: string | null;
}

export interface StudioSettings {
  geminiApiKey: string;
  geminiModel: string;
  audexumApiKey: string;
  audexumVoice: string;
  audexumSpeed: number;
  audexumBackend: string;
  audexumSteps: number;
  cloudflareAccountId: string;
  cloudflareApiToken: string;
  cloudflareWorkerUrl: string;
  pollinationsAuthMode: 'without-key' | 'with-key';
  pollinationsApiKey: string;
  pollinationsModel: string;
  cloudflareModel: string;
  puterModel: string;
  resolution: 'full-hd' | 'standard' | 'compact';
  autoGenerateVoice: boolean;
  includeSubtitlesInVideo: boolean;
  includeSceneBadgesInVideo: boolean;
}
