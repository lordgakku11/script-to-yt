import { PlannedScene, StyleMode, AspectRatio, ArtAtmosphere } from '../types';
import { getStylePromptDescription } from './imageGenerators';

export const SAMPLES: Record<string, string> = {
  horror: `Imagine this: You are sitting alone in your room late at night.
Everything outside is completely silent, and the shadows dance across your walls.
You stare into the dim corner, feeling a sudden chill run down your spine.
Your heart begins to race as you realize something is wrong.
Slowly, you turn around, feeling like someone is standing right behind you.`,
  space: `Deep within the Sagittarius constellation lies an anomaly that defies all known laws of physics.
A massive dying star emits strange pulsating rhythmic light signals.
Our deep space telescope zooms into the event horizon of an ancient black hole.
Suddenly, a colossal alien megastructure emerges from the swirling cosmic dust.
We are not alone in the universe.`,
  stoic: `Marcus Aurelius once wrote: You have power over your mind, not outside events.
A lone traveler walks steadily through a raging snowstorm in the mountains.
Every obstacle in your path is not an impediment; it is the way forward.
When the world around you is chaos, true strength is remaining calm inside.
Master your thoughts, conquer your fear, and claim your destiny.`,
  tech: `In the year 2045, human consciousness merged seamlessly with synthetic intelligence.
Soaring crystalline skyscrapers pierce neon-lit clouds in a bustling cyber metropolis.
Flying autonomous transports glide silently above bioluminescent sky bridges.
Inside an underground laboratory, a holographic neural core awakens for the first time.
A new era of civilization has officially begun.`,
};

/**
 * Intelligently splits a user's YouTube narration script into coherent, sequential scene beats.
 * Handles:
 * - Explicit scene markers (e.g. "Scene 1:", "[Scene 2]", "1. ", "Shot 1:", "Narration:")
 * - Newline-separated paragraphs or script lines
 * - Full sentence terminators (. ! ? । ;)
 * Never splits mid-sentence commas or single words, ensuring complete, natural voiceover sentences.
 */
export function parseScriptToSceneLines(script: string): string[] {
  const trimmed = script.trim();
  if (!trimmed) return [];

  // 1. Check for explicit scene markers like "Scene 1:", "Shot 1:", "[Scene 1]", "1.", etc.
  const sceneMarkerRegex = /(?:^|\n)(?:\[?(?:Scene|Shot|Beat|Part)\s*\d+\]?:?|\d+[\.\)])\s*/i;
  if (sceneMarkerRegex.test(trimmed)) {
    const rawParts = trimmed
      .split(/(?:^|\n)(?:\[?(?:Scene|Shot|Beat|Part)\s*\d+\]?:?|\d+[\.\)])\s*/i)
      .map((p) => p.replace(/^(?:Narration|Voiceover|Voice|Text):\s*/i, '').trim())
      .filter((p) => p.length > 0);
    if (rawParts.length > 1) {
      return rawParts;
    }
  }

  // 2. Check for multiline script (paragraphs or lines)
  const lines = trimmed
    .split(/\r?\n+/)
    .map((l) =>
      l
        .replace(/^(?:\[?(?:Scene|Shot|Beat|Part)\s*\d+\]?:?|\d+[\.\)])\s*/i, '')
        .replace(/^(?:Narration|Voiceover|Voice|Text):\s*/i, '')
        .trim()
    )
    .filter((l) => l.length > 0);

  if (lines.length > 1) {
    return lines;
  }

  // 3. Single block of text: split by full sentence terminators (. ! ? । ;)
  const sentences = trimmed
    .split(/(?<=[.!?।;])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  if (sentences.length > 0) {
    return sentences;
  }

  return [trimmed];
}

/**
 * Analyzes a scene's exact voice narration line (scriptPart) and constructs a
 * visual prompt and director cue that 100% matches what the voice is saying in that scene.
 */
export function buildMatchedScenePrompt(
  scriptPart: string,
  sceneIndex: number,
  styleMode: StyleMode,
  aspectRatio: AspectRatio,
  atmosphere: ArtAtmosphere = 'default'
): { image_prompt: string; visual_thinking: string } {
  const cleanPart = (scriptPart || '').replace(/\s+/g, ' ').trim();
  const lower = cleanPart.toLowerCase();
  const styleDesc = getStylePromptDescription(styleMode, atmosphere);

  // Detect emotion, action, and setting directly from the voice narration text
  let characterCue = '';
  let cameraShot = '';

  const shotFramings = [
    'cinematic medium shot',
    'focused close-up shot',
    'wide establishing shot',
    'dramatic eye-level framing',
    'dynamic over-the-shoulder view',
    'expressive three-quarter angle shot',
  ];
  cameraShot = shotFramings[sceneIndex % shotFramings.length];

  if (styleMode === 'stickman') {
    if (/(fear|chill|scare|horror|shadow|dark|behind|wrong|race|heart|panic|ghost|night|silent)/.test(lower)) {
      characterCue = 'expressive stick figure character reacting to the exact moment with tense posture and wide alert eyes in the scene environment';
    } else if (/(think|mind|power|calm|master|strength|wisdom|obstacle|walk|path|focus)/.test(lower)) {
      characterCue = 'focused stick figure character demonstrating the exact action with determined posture and clear visual props matching the narration';
    } else if (/(space|star|planet|universe|alien|black hole|telescope|galaxy|cosmic|future|cyber|robot|ai|city|sky|fly)/.test(lower)) {
      characterCue = 'stick figure character inside a detailed hand-drawn doodle environment illustrating the exact sci-fi / cosmic subject of the narration';
    } else {
      characterCue = 'expressive stick figure character directly acting out the exact narration moment with clear visual storytelling props';
    }

    const image_prompt = `Exact visual illustration of "${cleanPart}". ${cameraShot} showing ${characterCue}, directly depicting: ${cleanPart}. ${styleDesc}, ${aspectRatio} aspect ratio, no text, no words, no watermark, no captions.`;
    const visual_thinking = `Scene #${sceneIndex + 1} Voice-Matched Visual (${cameraShot}): Directly illustrates "${cleanPart.slice(0, 55)}${cleanPart.length > 55 ? '...' : ''}"`;
    return { image_prompt, visual_thinking };
  }

  if (styleMode === 'cartoon') {
    if (/(fear|chill|scare|horror|shadow|dark|behind|wrong|race|heart|night|silent)/.test(lower)) {
      characterCue = '3D Pixar-style animated scene with dramatic suspenseful lighting and expressive character acting out the exact narration';
    } else if (/(space|star|universe|alien|black hole|telescope|future|cyber|ai|city|sky)/.test(lower)) {
      characterCue = 'vibrant 3D animated sci-fi scene directly showcasing the exact environment and subject described in the narration';
    } else {
      characterCue = 'vibrant 3D Pixar-style animated scene directly acting out the exact subject and action of the narration';
    }

    const image_prompt = `Exact visual illustration of "${cleanPart}". ${cameraShot}, ${characterCue}, depicting: ${cleanPart}. ${styleDesc}, ${aspectRatio} aspect ratio, no text, no watermark, no captions.`;
    const visual_thinking = `Scene #${sceneIndex + 1} Voice-Matched Visual (${cameraShot}): Directly illustrates "${cleanPart.slice(0, 55)}${cleanPart.length > 55 ? '...' : ''}"`;
    return { image_prompt, visual_thinking };
  }

  // Realistic mode
  const image_prompt = `Exact photorealistic visual depiction of "${cleanPart}". ${cameraShot} directly illustrating every detail of: ${cleanPart}. ${styleDesc}, ${aspectRatio} aspect ratio, no text, no watermark, no captions.`;
  const visual_thinking = `Scene #${sceneIndex + 1} Voice-Matched Visual (${cameraShot}): Directly illustrates "${cleanPart.slice(0, 55)}${cleanPart.length > 55 ? '...' : ''}"`;
  return { image_prompt, visual_thinking };
}

export function instantLocalBreakdown(
  script: string,
  styleMode: StyleMode,
  aspectRatio: AspectRatio,
  atmosphere: ArtAtmosphere = 'default'
): PlannedScene[] {
  const clauses = parseScriptToSceneLines(script);

  return clauses.map((clause, index) => {
    const cleanPart = clause.replace(/\s+/g, ' ').trim();
    const { image_prompt, visual_thinking } = buildMatchedScenePrompt(
      cleanPart,
      index,
      styleMode,
      aspectRatio,
      atmosphere
    );
    return {
      scene_number: index + 1,
      script_part: cleanPart,
      visual_thinking,
      image_prompt,
    };
  });
}
