import { AspectRatio, EngineType, StyleMode, ArtAtmosphere } from '../types';

export function getStylePromptDescription(styleMode: StyleMode, atmosphere: ArtAtmosphere = 'default'): string {
  if (styleMode === 'stickman') {
    return 'minimalist black ink hand-drawn stick figure line art, clean doodle illustration, expressive face with simple round head and stick limbs, smooth solid clean eye-friendly light gray studio background (#d1d5db / soft neutral gray), high contrast, viral YouTube explainer animation aesthetic, absolutely no text, no watermark, no captions';
  } else if (styleMode === 'cartoon') {
    return 'vibrant 3D Pixar Disney style animated cartoon, rich colors, soft whimsical lighting, expressive stylized characters, detailed cartoon textures, high quality digital animation render, cinematic framing, no text, no watermark, no captions';
  } else {
    let atmoDesc = 'cinematic lighting, dramatic shadows, photorealistic scene, highly detailed';
    if (atmosphere === 'dark-thriller') atmoDesc = 'dark atmospheric thriller lighting, deep shadows, moody neon rim light, mysterious fog, 8k cinematic realism';
    if (atmosphere === 'humorous-fun') atmoDesc = 'bright cheerful daytime lighting, vivid punchy colors, playful photorealistic framing, sharp focus';
    if (atmosphere === 'dramatic-epic') atmoDesc = 'epic cinematic composition, golden hour god rays, dramatic haze, dynamic motion, Hollywood movie still';
    if (atmosphere === 'educational-clean') atmoDesc = 'clean studio lighting, soft depth of field, sharp crisp subjects, documentary realism, immaculate detail';
    return `${atmoDesc}, photorealistic 8k render, masterpiece composition, no text, no watermark, no captions`;
  }
}

export function getDimensions(aspectRatio: AspectRatio): { width: number; height: number } {
  if (aspectRatio === '16:9') {
    return { width: 1920, height: 1080 }; // Fixed 16:9 Full HD Landscape
  } else {
    return { width: 1080, height: 1920 }; // Fixed 9:16 Full HD Shorts/Reels Portrait
  }
}

export function generateCleanFilename(index: number, scriptPart: string, extension: string = 'png'): string {
  const num = String(index + 1).padStart(2, '0');
  const slug = (scriptPart || 'scene')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 30);
  return `scene_${num}_${slug || 'beat'}.${extension}`;
}

/**
 * Ensures any image blob is strictly normalized to the exact targetWidth x targetHeight (1920x1080 or 1080x1920).
 * If the upstream AI provider returns square (1024x1024) or non-matching dimensions,
 * this centers and crops (cover) onto a pristine canvas so the output is 100% fixed size.
 */
export async function ensureExactDimensions(
  blob: Blob,
  targetWidth: number,
  targetHeight: number
): Promise<{ blob: Blob; blobUrl: string }> {
  return new Promise((resolve) => {
    const img = new Image();
    const tempUrl = URL.createObjectURL(blob);
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      // If already exact dimensions, return directly
      if (img.naturalWidth === targetWidth && img.naturalHeight === targetHeight) {
        resolve({ blob, blobUrl: tempUrl });
        return;
      }

      // Draw onto exact fixed target canvas
      const canvas = document.createElement('canvas');
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        resolve({ blob, blobUrl: tempUrl });
        return;
      }

      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';

      // Fill dark neutral background
      ctx.fillStyle = '#090d12';
      ctx.fillRect(0, 0, targetWidth, targetHeight);

      // Smart cover center crop
      const scale = Math.max(targetWidth / img.naturalWidth, targetHeight / img.naturalHeight);
      const drawWidth = img.naturalWidth * scale;
      const drawHeight = img.naturalHeight * scale;
      const drawX = (targetWidth - drawWidth) / 2;
      const drawY = (targetHeight - drawHeight) / 2;

      ctx.drawImage(img, drawX, drawY, drawWidth, drawHeight);

      canvas.toBlob(
        (fixedBlob) => {
          URL.revokeObjectURL(tempUrl);
          if (fixedBlob) {
            const fixedUrl = URL.createObjectURL(fixedBlob);
            resolve({ blob: fixedBlob, blobUrl: fixedUrl });
          } else {
            resolve({ blob, blobUrl: tempUrl });
          }
        },
        'image/png',
        1.0
      );
    };

    img.onerror = () => {
      resolve({ blob, blobUrl: tempUrl });
    };

    img.src = tempUrl;
  });
}

// 1. Pollinations AI (Two Modes: Without API Key vs With API Key)
export const POLLINATIONS_MODELS = [
  { id: 'flux', label: 'FLUX.1 Schnell (High Quality, Standard)', pro: false },
  { id: 'z-image-turbo', label: 'Z-Image Turbo (Ultra Fast)', pro: false },
  { id: 'flux-2-flex', label: 'FLUX.2 Flex (Pro Model)', pro: true },
  { id: 'flux-2-pro', label: 'FLUX.2 Pro (Ultra Quality Pro)', pro: true },
  { id: 'gpt-image-2', label: 'GPT Image 2 (Stylized Artistic)', pro: false },
  { id: 'nanobanana2', label: 'Gemini 3.1 Flash Image (Detailed)', pro: true },
  { id: 'seedream-pro', label: 'SeeDream 4.5 Pro (Vibrant)', pro: true },
  { id: 'krea', label: 'Krea 2 Medium (Aesthetic Realism)', pro: true },
  { id: 'recraft-vector', label: 'Recraft Vector Art (Graphic Vector)', pro: true },
  { id: 'sana', label: 'Sana LCM (Lightweight)', pro: false },
] as const;

export function resolvePollinationsModel(rawModel?: string): string {
  if (!rawModel) return 'z-image-turbo';
  const norm = rawModel.trim().toLowerCase();
  const known = POLLINATIONS_MODELS.find(m => m.id === norm);
  if (known) return known.id;
  // Aliases for legacy/user inputs
  if (norm === 'flux-pro') return 'flux-2-pro';
  if (norm === 'flux-realism' || norm === 'flux-anime' || norm === 'flux-3d') return 'flux';
  if (norm === 'nanobanana' || norm === 'nanobanana-2') return 'nanobanana2';
  if (norm === 'dreamshaper') return 'sana';
  return 'z-image-turbo';
}

export function sanitizeApiKey(key?: string): string {
  if (!key) return '';
  let clean = key.trim();
  clean = clean.replace(/^Bearer\s+/i, '').trim();
  clean = clean.replace(/^["']|["']$/g, '').trim();
  return clean;
}

export async function verifyPollinationsApiKey(
  apiKey: string
): Promise<{ valid: boolean; message: string; status?: number; balance?: number; keyType?: string }> {
  const cleanKey = sanitizeApiKey(apiKey);
  if (!cleanKey) {
    return { valid: false, message: 'Please enter an API Key to test.' };
  }

  // Official Pollinations account check endpoints that validate keys without burning pollen or timing out:
  const testEndpoints = [
    'https://gen.pollinations.ai/account/key',
    'https://gen.pollinations.ai/account/balance',
    'https://gen.pollinations.ai/account/profile',
  ];

  const headers = {
    'Authorization': `Bearer ${cleanKey}`,
    'x-api-key': cleanKey,
    'Accept': 'application/json',
  };

  let lastStatus = 0;
  let lastMessage = '';

  for (const endpoint of testEndpoints) {
    try {
      // Use proxy to avoid browser CORS preflight blocking
      const proxyUrl = `/api/proxy?url=${encodeURIComponent(endpoint)}`;
      const res = await fetch(proxyUrl, { headers });
      lastStatus = res.status;

      if (res.ok) {
        const data = await res.json().catch(() => ({}));
        let balanceStr = '';
        if (typeof data.balance === 'number') {
          balanceStr = ` • Balance: ${data.balance} Pollen`;
        } else if (typeof data.pollenBudget === 'number') {
          balanceStr = ` • Budget: ${data.pollenBudget} Pollen`;
        }
        const typeStr = data.type ? ` (${data.type})` : '';
        const nameStr = data.name ? ` "${data.name}"` : '';

        return {
          valid: true,
          status: 200,
          message: `Active & Valid API Key${typeStr}${nameStr}! Connected to Pollinations AI${balanceStr}`,
          balance: typeof data.balance === 'number' ? data.balance : data.pollenBudget,
          keyType: data.type,
        };
      }

      const errText = await res.text().catch(() => '');
      try {
        const json = JSON.parse(errText);
        if (json.error?.message) {
          lastMessage = json.error.message;
        }
      } catch (_) {
        if (errText) lastMessage = errText.slice(0, 150);
      }
    } catch (e: any) {
      lastMessage = e.message || 'Network check failed';
    }
  }

  if (lastStatus === 401) {
    return {
      valid: false,
      status: 401,
      message: lastMessage || 'API key unauthorized. Please copy your key from enter.pollinations.ai/keys',
    };
  }

  if (lastStatus === 402) {
    return {
      valid: false,
      status: 402,
      message: 'Valid key, but balance is 0 Pollen (HTTP 402). Auto-fallback will use fast free server.',
    };
  }

  return {
    valid: false,
    status: lastStatus,
    message: lastMessage || `Verification returned HTTP ${lastStatus || 'error'}`,
  };
}

export async function generatePollinationsImage(
  prompt: string,
  width: number,
  height: number,
  model: string = 'z-image-turbo',
  apiKey?: string,
  options?: { fallbackToFreeOnKeyError?: boolean }
): Promise<{ url: string; blobUrl: string; blob: Blob; usedFallback?: boolean }> {
  const seed = Math.floor(Math.random() * 1000000000);
  // Sanitize prompt text (trim and limit length to prevent URL length limits)
  const cleanPrompt = prompt.trim().slice(0, 500);
  const encodedPrompt = encodeURIComponent(cleanPrompt);
  const cleanModel = resolvePollinationsModel(model);
  const cleanKey = sanitizeApiKey(apiKey);
  const hasKey = cleanKey.length > 0;

  // If apiKey was explicitly passed but is empty:
  if (apiKey !== undefined && !hasKey) {
    throw new Error('Pollinations API Key is missing. Please paste your key from enter.pollinations.ai/keys, or switch to "Without API Key" (100% Free).');
  }

  // Dimension normalization for upstream generation:
  // Models on gen.pollinations.ai (like flux-2-pro, mai, flex) require multiples of 16 and max 1.6MP.
  // 1920x1080 has 1080 % 16 = 8, which triggers HTTP 400 Bad Request on those models.
  // We request 1280x720 (16:9, both divisible by 16) or 720x1280 (9:16),
  // then canvas-upscale to exact 1920x1080 (Full HD) with zero quality loss!
  const isLandscape = width >= height;
  const genW = isLandscape ? 1280 : 720;
  const genH = isLandscape ? 720 : 1280;

  const headers: Record<string, string> = {
    'Accept': 'image/*',
  };

  let primaryUrl: string;
  if (hasKey) {
    primaryUrl = `https://gen.pollinations.ai/image/${encodedPrompt}?width=${genW}&height=${genH}&model=${encodeURIComponent(cleanModel)}&seed=${seed}&key=${encodeURIComponent(cleanKey)}`;
    headers['Authorization'] = `Bearer ${cleanKey}`;
    headers['x-api-key'] = cleanKey;
  } else {
    // 100% Free Anonymous Mode (Without API Key)
    primaryUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=${genW}&height=${genH}&model=${encodeURIComponent(cleanModel)}&seed=${seed}&nologo=true`;
  }

  // Helper to fetch via proxy first (for reliability and headers preservation)
  const fetchImageWithProxy = async (targetUrl: string, reqHeaders?: Record<string, string>): Promise<Response> => {
    // Try via proxy first to guarantee CORS and header forwarding
    const proxyUrl = `/api/proxy?url=${encodeURIComponent(targetUrl)}`;
    try {
      const res = await fetch(proxyUrl, {
        headers: reqHeaders && Object.keys(reqHeaders).length ? reqHeaders : undefined,
      });
      if (res.ok) return res;
    } catch (err) {
      console.warn('[Pollinations Proxy] Proxy fetch failed, attempting direct fetch...', err);
    }

    // Direct fetch fallback
    return fetch(targetUrl, {
      headers: reqHeaders && Object.keys(reqHeaders).length ? reqHeaders : undefined,
    });
  };

  let res: Response | null = null;
  let fetchError: Error | null = null;

  try {
    res = await fetchImageWithProxy(primaryUrl, headers);
  } catch (err: any) {
    fetchError = err;
  }

  // Check if primary succeeded
  if (res && res.ok) {
    const rawBlob = await res.blob();
    const normalized = await ensureExactDimensions(rawBlob, width, height);
    return { url: primaryUrl, blobUrl: normalized.blobUrl, blob: normalized.blob };
  }

  // If primary attempt failed (e.g. 401 invalid key, 402 balance 0, 400 dimension/model error, 500 upstream):
  const status = res ? res.status : 0;
  console.warn(`[Pollinations] Primary generation attempt returned status ${status}. Attempting graceful fallback...`);

  // Attempt Fallback: Use reliable image.pollinations.ai with FLUX or z-image-turbo
  const fallbackModel = (cleanModel === 'flux-2-pro' || cleanModel === 'flux-2-flex' || cleanModel === 'gpt-image-2')
    ? 'flux'
    : cleanModel;

  const fallbackUrl = hasKey
    ? `https://image.pollinations.ai/prompt/${encodedPrompt}?width=${genW}&height=${genH}&model=${fallbackModel}&seed=${seed}&nologo=true&key=${encodeURIComponent(cleanKey)}`
    : `https://image.pollinations.ai/prompt/${encodedPrompt}?width=${genW}&height=${genH}&model=${fallbackModel}&seed=${seed}&nologo=true`;

  try {
    const fallbackRes = await fetchImageWithProxy(fallbackUrl);
    if (fallbackRes.ok) {
      const rawBlob = await fallbackRes.blob();
      const normalized = await ensureExactDimensions(rawBlob, width, height);
      return {
        url: fallbackUrl,
        blobUrl: normalized.blobUrl,
        blob: normalized.blob,
        usedFallback: true,
      };
    }
  } catch (fbErr) {
    console.warn('[Pollinations] Fallback 1 failed, trying universal prompt...', fbErr);
  }

  // Universal last-resort fallback on image.pollinations.ai
  const universalUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=1280&height=720&nologo=true&seed=${seed}`;
  try {
    const uniRes = await fetchImageWithProxy(universalUrl);
    if (uniRes.ok) {
      const rawBlob = await uniRes.blob();
      const normalized = await ensureExactDimensions(rawBlob, width, height);
      return {
        url: universalUrl,
        blobUrl: normalized.blobUrl,
        blob: normalized.blob,
        usedFallback: true,
      };
    }
  } catch (uniErr) {
    console.warn('[Pollinations] Universal fallback failed', uniErr);
  }

  // If all failed, throw descriptive error
  const errDetail = fetchError?.message || `HTTP ${status || 'unknown'}`;
  throw new Error(`Pollinations AI generation failed (${errDetail}). Please check your connection or switch model.`);
}

// 2. Cloudflare Workers AI
export async function generateCloudflareImage(
  prompt: string,
  width: number,
  height: number,
  workerUrl: string = 'https://fffff.adon61144.workers.dev/api/generate'
): Promise<{ url: string; blobUrl: string; blob: Blob }> {
  const targetUrl = workerUrl || 'https://fffff.adon61144.workers.dev/api/generate';
  let response: Response;

  try {
    // Try via CORS proxy first
    response = await fetch(`/api/proxy?url=${encodeURIComponent(targetUrl)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, width, height, aspect_ratio: width > height ? '16:9' : '9:16' }),
    });
    if (!response.ok) {
      throw new Error(`Proxy error ${response.status}`);
    }
  } catch {
    // Direct attempt
    response = await fetch(targetUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, width, height, aspect_ratio: width > height ? '16:9' : '9:16' }),
    });
  }

  if (!response.ok) {
    const errText = await response.text().catch(() => '');
    throw new Error(`Cloudflare Worker HTTP ${response.status}: ${errText}`);
  }

  const rawBlob = await response.blob();
  const normalized = await ensureExactDimensions(rawBlob, width, height);
  return { url: normalized.blobUrl, blobUrl: normalized.blobUrl, blob: normalized.blob };
}

// Dynamic loader for Puter.js on demand
async function ensurePuterLoaded(): Promise<any> {
  const win = typeof window !== 'undefined' ? (window as any) : {};
  if (win.puter && win.puter.ai?.txt2img) {
    return win.puter;
  }
  return new Promise((resolve, reject) => {
    const existing = document.querySelector('script[src*="js.puter.com"]');
    if (existing) {
      if (win.puter?.ai?.txt2img) {
        resolve(win.puter);
        return;
      }
      existing.addEventListener('load', () => resolve(win.puter));
      existing.addEventListener('error', () => reject(new Error('Failed to load Puter.js library.')));
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://js.puter.com/v2/';
    script.async = true;
    script.onload = () => resolve(win.puter);
    script.onerror = () => reject(new Error('Failed to load Puter.js library.'));
    document.head.appendChild(script);
  });
}

// 3. Puter.js
export async function generatePuterImage(
  prompt: string,
  width: number,
  height: number,
  model: string = 'flux'
): Promise<{ url: string; blobUrl: string; blob: Blob }> {
  const puter = await ensurePuterLoaded();
  if (!puter || !puter.ai?.txt2img) {
    throw new Error('Puter.js library is not available in browser.');
  }

  const result = await puter.ai.txt2img(prompt, { model: model || 'flux' });
  const rawUrl =
    result instanceof HTMLElement
      ? (result as HTMLImageElement).src
      : typeof result === 'string'
      ? result
      : result?.src || result?.url;

  if (!rawUrl) {
    throw new Error('No image URL returned by Puter.js.');
  }

  const res = await fetch(rawUrl);
  const rawBlob = await res.blob();
  const normalized = await ensureExactDimensions(rawBlob, width, height);
  return { url: rawUrl, blobUrl: normalized.blobUrl, blob: normalized.blob };
}

// Dispatcher: Always outputs exact fixed dimensions (1920x1080 for 16:9, or 1080x1920 for 9:16)
export async function generateSingleImageDirect(
  prompt: string,
  engine: EngineType,
  width: number,
  height: number,
  options?: {
    pollinationsModel?: string;
    pollinationsApiKey?: string;
    pollinationsAuthMode?: 'without-key' | 'with-key';
    cloudflareWorkerUrl?: string;
    puterModel?: string;
  }
): Promise<{ url: string; blobUrl: string; blob: Blob }> {
  if (engine === 'cloudflare') {
    return generateCloudflareImage(prompt, width, height, options?.cloudflareWorkerUrl);
  } else if (engine === 'puter') {
    return generatePuterImage(prompt, width, height, options?.puterModel);
  } else {
    const apiKeyToUse =
      options?.pollinationsAuthMode === 'with-key' ? options?.pollinationsApiKey : undefined;
    return generatePollinationsImage(
      prompt,
      width,
      height,
      options?.pollinationsModel,
      apiKeyToUse
    );
  }
}
