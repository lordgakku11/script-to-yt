import { AspectRatio, CompiledSceneTimeline, GeneratedItem, SceneAudioData } from '../types';
import { audioBufferToWav, getAudioContext } from './audio';

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function drawSceneCaptions(
  ctx: CanvasRenderingContext2D,
  text: string,
  width: number,
  height: number,
  isShort: boolean
) {
  if (!text || !text.trim()) return;

  ctx.save();
  const fontSize = isShort ? 42 : 36;
  ctx.font = `700 ${fontSize}px "Plus Jakarta Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  const maxLineWidth = width * 0.84;
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let currentLine = '';

  for (const w of words) {
    const testLine = currentLine ? `${currentLine} ${w}` : w;
    if (ctx.measureText(testLine).width > maxLineWidth) {
      if (currentLine) lines.push(currentLine);
      currentLine = w;
    } else {
      currentLine = testLine;
    }
  }
  if (currentLine) lines.push(currentLine);

  const lineHeight = fontSize * 1.35;
  const boxPaddingX = 36;
  const boxPaddingY = 18;
  const totalTextHeight = lines.length * lineHeight;
  const bottomY = isShort ? height - 340 : height - 120;
  const boxY = bottomY - totalTextHeight / 2 - boxPaddingY;

  let maxW = 0;
  lines.forEach((l) => {
    maxW = Math.max(maxW, ctx.measureText(l).width);
  });
  const boxW = Math.min(width * 0.92, maxW + boxPaddingX * 2);
  const boxX = (width - boxW) / 2;
  const boxH = totalTextHeight + boxPaddingY * 2;

  ctx.fillStyle = 'rgba(9, 13, 18, 0.84)';
  roundRect(ctx, boxX, boxY, boxW, boxH, 18);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.24)';
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.shadowColor = 'rgba(0, 0, 0, 0.95)';
  ctx.shadowBlur = 10;
  ctx.fillStyle = '#ffffff';

  lines.forEach((line, idx) => {
    const lineY = boxY + boxPaddingY + (idx + 0.5) * lineHeight;
    ctx.fillText(line, width / 2, lineY);
  });

  ctx.restore();
}

export interface CompileVideoOptions {
  includeSubtitles?: boolean;
  includeBadges?: boolean;
  crossfadeDuration?: number;
}

function withTimeout<T>(promise: Promise<T>, ms: number, fallbackValue: T): Promise<T> {
  return new Promise<T>((resolve) => {
    const timer = window.setTimeout(() => resolve(fallbackValue), ms);
    promise
      .then((val) => {
        clearTimeout(timer);
        resolve(val);
      })
      .catch(() => {
        clearTimeout(timer);
        resolve(fallbackValue);
      });
  });
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to encode blob to base64'));
      }
    };
    reader.onerror = () => reject(new Error('FileReader error'));
    reader.readAsDataURL(blob);
  });
}

type DrawableVisual = ImageBitmap | HTMLImageElement | null;

/**
 * Loads a single scene's visual with strict timeouts.
 */
async function loadSceneVisual(item: GeneratedItem): Promise<{
  visual: DrawableVisual;
  previewUrl: string;
}> {
  const loadImgWithTimeout = (src: string, useCors: boolean, timeoutMs = 3500): Promise<HTMLImageElement | null> =>
    new Promise((resolve) => {
      if (!src) return resolve(null);
      let settled = false;
      const timer = window.setTimeout(() => {
        if (!settled) {
          settled = true;
          resolve(null);
        }
      }, timeoutMs);

      const img = new Image();
      if (useCors && !src.startsWith('blob:') && !src.startsWith('data:')) {
        img.crossOrigin = 'anonymous';
      }
      img.onload = () => {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          resolve(img.naturalWidth > 0 ? img : null);
        }
      };
      img.onerror = () => {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          resolve(null);
        }
      };
      img.src = src;
    });

  if (item.imageBlob && item.imageBlob.size > 0 && typeof createImageBitmap === 'function') {
    const bmp = await withTimeout(createImageBitmap(item.imageBlob), 2500, null);
    if (bmp) {
      return {
        visual: bmp,
        previewUrl: item.localBlobUrl || item.imageUrl || '',
      };
    }
  }

  if (item.localBlobUrl) {
    const img = await loadImgWithTimeout(item.localBlobUrl, false, 2500);
    if (img) {
      return { visual: img, previewUrl: item.localBlobUrl };
    }
  }

  if (item.imageBlob && item.imageBlob.size > 0) {
    const freshUrl = URL.createObjectURL(item.imageBlob);
    const img = await loadImgWithTimeout(freshUrl, false, 2500);
    if (img) {
      return { visual: img, previewUrl: item.localBlobUrl || freshUrl };
    }
  }

  if (item.imageUrl) {
    const img = await loadImgWithTimeout(item.imageUrl, true, 3500);
    if (img) {
      return { visual: img, previewUrl: item.imageUrl };
    }
  }

  return {
    visual: null,
    previewUrl: item.localBlobUrl || item.imageUrl || '',
  };
}

/**
 * Paints ONE static frame for a scene onto the reusable canvas and returns a JPEG data URL.
 * Zero 30fps loop, zero GPU animation overhead.
 */
function renderStaticSceneJpeg(
  canvas: HTMLCanvasElement,
  visual: DrawableVisual,
  item: GeneratedItem,
  idx: number,
  totalScenes: number,
  width: number,
  height: number,
  isShort: boolean,
  includeSubtitles: boolean,
  includeBadges: boolean
): string {
  const ctx = canvas.getContext('2d', { alpha: false });
  if (!ctx) return '';

  ctx.fillStyle = '#090d12';
  ctx.fillRect(0, 0, width, height);

  let drewVisual = false;
  if (visual) {
    const vWidth = 'naturalWidth' in visual ? visual.naturalWidth : visual.width;
    const vHeight = 'naturalHeight' in visual ? visual.naturalHeight : visual.height;
    if (vWidth > 0 && vHeight > 0) {
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      const scale = Math.max(width / vWidth, height / vHeight);
      const drawW = vWidth * scale;
      const drawH = vHeight * scale;
      const drawX = (width - drawW) / 2;
      const drawY = (height - drawH) / 2;
      ctx.drawImage(visual, drawX, drawY, drawW, drawH);
      drewVisual = true;
    }
  }

  if (!drewVisual) {
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, '#0f172a');
    grad.addColorStop(1, '#1e1b4b');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);

    ctx.fillStyle = '#f59e0b';
    ctx.font = 'bold 44px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`SCENE ${String(idx + 1).padStart(2, '0')}`, width / 2, height / 2 - 40);

    ctx.fillStyle = '#f8fafc';
    ctx.font = '600 32px "Plus Jakarta Sans", sans-serif';
    ctx.fillText((item.scriptPart || '').slice(0, 65), width / 2, height / 2 + 25);
  }

  if (includeBadges) {
    const topGrad = ctx.createLinearGradient(0, 0, 0, 140);
    topGrad.addColorStop(0, 'rgba(9, 13, 18, 0.70)');
    topGrad.addColorStop(1, 'rgba(9, 13, 18, 0)');
    ctx.fillStyle = topGrad;
    ctx.fillRect(0, 0, width, 140);

    ctx.save();
    ctx.font = 'bold 28px "JetBrains Mono", monospace';
    ctx.fillStyle = '#fbbf24';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(
      `SCENE ${String(idx + 1).padStart(2, '0')} / ${String(totalScenes).padStart(2, '0')}`,
      48,
      56
    );
    ctx.restore();
  }

  if (includeSubtitles && item.scriptPart) {
    const botGrad = ctx.createLinearGradient(0, height - 280, 0, height);
    botGrad.addColorStop(0, 'rgba(9, 13, 18, 0)');
    botGrad.addColorStop(1, 'rgba(9, 13, 18, 0.85)');
    ctx.fillStyle = botGrad;
    ctx.fillRect(0, height - 280, width, 280);

    drawSceneCaptions(ctx, item.scriptPart, width, height, isShort);
  }

  return canvas.toDataURL('image/jpeg', 0.92);
}

/**
 * Prepares a clean 44.1kHz stereo AudioBuffer with 8ms anti-pop micro-fades for a single scene.
 */
function prepareCleanSceneBuffer(
  sourceBuffer: AudioBuffer | null,
  fallbackDuration: number,
  audioCtx: AudioContext
): AudioBuffer {
  const targetSampleRate = 44100;
  if (!sourceBuffer || sourceBuffer.length === 0) {
    const silentSamples = Math.max(1, Math.round(fallbackDuration * targetSampleRate));
    return audioCtx.createBuffer(2, silentSamples, targetSampleRate);
  }

  const duration = sourceBuffer.duration;
  const targetSamples = Math.max(1, Math.round(duration * targetSampleRate));
  const outBuffer = audioCtx.createBuffer(2, targetSamples, targetSampleRate);
  const outL = outBuffer.getChannelData(0);
  const outR = outBuffer.getChannelData(1);

  const srcL = sourceBuffer.getChannelData(0);
  const srcR = sourceBuffer.numberOfChannels > 1 ? sourceBuffer.getChannelData(1) : srcL;
  const srcLen = sourceBuffer.length;

  const fadeSamples = Math.min(Math.round(0.008 * targetSampleRate), Math.floor(targetSamples / 4));

  for (let i = 0; i < targetSamples; i++) {
    const srcIdx = Math.min(srcLen - 1, Math.floor((i / targetSamples) * srcLen));
    let gain = 1.0;
    if (i < fadeSamples) {
      gain = i / fadeSamples;
    } else if (i > targetSamples - fadeSamples) {
      gain = (targetSamples - i) / fadeSamples;
    }
    outL[i] = srcL[srcIdx] * gain;
    outR[i] = srcR[srcIdx] * gain;
  }

  return outBuffer;
}

/**
 * Zero-GPU Script-Flow MP4 Video Compiler:
 * 1. Follows the exact flow of the script (Scene 1 -> Scene 2 -> ... -> Scene N).
 * 2. For each scene, takes ONLY that scene's static image and holds it from the exact
 *    start to the exact end of that scene's voiceover length.
 * 3. Combines all scene MP4 clips in script flow order and exports a universal 1080p .mp4
 *    without using heavy browser GPU processing.
 */
export async function compileSceneVideo(
  items: GeneratedItem[],
  audioMap: Record<number, SceneAudioData>,
  aspectRatio: AspectRatio,
  onProgress: (pct: number, status: string) => void,
  options: CompileVideoOptions = {}
): Promise<{
  blob: Blob;
  url: string;
  mimeType: string;
  totalDuration: number;
  sceneTimelines: CompiledSceneTimeline[];
}> {
  const {
    includeSubtitles = false,
    includeBadges = false,
  } = options;

  const isShort = aspectRatio === '9:16';
  const width = isShort ? 1080 : 1920;
  const height = isShort ? 1920 : 1080;

  onProgress(40, 'Initializing zero-GPU MP4 compiler...');

  const audioCtx = getAudioContext();

  // Initialize server-side MP4 compilation job
  const initRes = await fetch('/api/video/init', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
  });
  if (!initRes.ok) {
    throw new Error('Could not initialize MP4 compiler service');
  }
  const { jobId } = await initRes.json();

  // Single lightweight offscreen canvas reused across scenes (1 static snapshot per scene)
  const singleCanvas = document.createElement('canvas');
  singleCanvas.width = width;
  singleCanvas.height = height;

  const sceneTimelines: CompiledSceneTimeline[] = [];
  let runningOffset = 0;

  // Process each scene sequentially in exact script flow order
  for (let idx = 0; idx < items.length; idx++) {
    const item = items[idx];
    const audioData = audioMap[idx];

    const pct = 42 + Math.round(((idx + 1) / items.length) * 50);
    onProgress(
      pct,
      `Scene ${idx + 1}/${items.length}: Matching static image to voice length ("${item.scriptPart.slice(0, 28)}...")`
    );

    // 1. Decode / verify this scene's voiceover AudioBuffer
    let rawBuffer: AudioBuffer | null = audioData?.audioBuffer || null;
    if (!rawBuffer && audioData?.blob) {
      const ab = await withTimeout(audioData.blob.arrayBuffer(), 2500, null);
      if (ab) {
        rawBuffer = await withTimeout(audioCtx.decodeAudioData(ab.slice(0)), 2500, null);
      }
    }
    if (!rawBuffer && audioData?.url) {
      try {
        const res = await withTimeout(fetch(audioData.url), 2500, null);
        if (res && res.ok) {
          const ab = await withTimeout(res.arrayBuffer(), 2000, null);
          if (ab) {
            rawBuffer = await withTimeout(audioCtx.decodeAudioData(ab.slice(0)), 2500, null);
          }
        }
      } catch (_) {}
    }

    const fallbackDur =
      audioData?.duration && audioData.duration > 0.3 ? audioData.duration : 3.0;
    const cleanBuffer = prepareCleanSceneBuffer(rawBuffer, fallbackDur, audioCtx);
    const sceneDur = Math.max(0.25, cleanBuffer.duration);

    // Convert this scene's voiceover to WAV base64
    const wavBlob = audioBufferToWav(cleanBuffer);
    const audioBase64 = await blobToBase64(wavBlob);

    // 2. Load this scene's image and paint 1 static JPEG frame
    const loadedVisual = await loadSceneVisual(item);
    const imageBase64 = renderStaticSceneJpeg(
      singleCanvas,
      loadedVisual.visual,
      item,
      idx,
      items.length,
      width,
      height,
      isShort,
      includeSubtitles,
      includeBadges
    );

    if (loadedVisual.visual && 'close' in loadedVisual.visual && typeof loadedVisual.visual.close === 'function') {
      try {
        loadedVisual.visual.close();
      } catch (_) {}
    }

    // 3. Encode this scene's static image + voiceover into an exact-duration scene MP4 clip
    const sceneRes = await fetch('/api/video/scene', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jobId,
        sceneIndex: idx,
        duration: sceneDur,
        imageBase64,
        audioBase64,
        width,
        height,
      }),
    });

    if (!sceneRes.ok) {
      const errJson = await sceneRes.json().catch(() => ({}));
      throw new Error(errJson.error || `Failed to encode Scene ${idx + 1}`);
    }

    sceneTimelines.push({
      sceneIndex: idx,
      sceneNumber: item.sceneNumber || idx + 1,
      scriptPart: item.scriptPart,
      imageUrl: loadedVisual.previewUrl,
      start: runningOffset,
      end: runningOffset + sceneDur,
      duration: sceneDur,
    });
    runningOffset += sceneDur;
  }

  const totalDuration = Math.max(0.5, runningOffset);

  // 4. Combine all scene MP4 clips in script flow order into final .mp4
  onProgress(95, `Combining all ${items.length} scene clips in script flow into MP4...`);

  const finalizeRes = await fetch('/api/video/finalize', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jobId,
      width,
      height,
    }),
  });

  if (!finalizeRes.ok) {
    const errJson = await finalizeRes.json().catch(() => ({}));
    throw new Error(errJson.error || 'Failed to finalize MP4 export');
  }

  const mp4ArrayBuffer = await finalizeRes.arrayBuffer();
  const compiledBlob = new Blob([mp4ArrayBuffer], { type: 'video/mp4' });
  const compiledUrl = URL.createObjectURL(compiledBlob);

  onProgress(
    100,
    `MP4 Video Ready! All ${items.length} scenes combined in script flow (${totalDuration.toFixed(1)}s).`
  );

  return {
    blob: compiledBlob,
    url: compiledUrl,
    mimeType: 'video/mp4',
    totalDuration,
    sceneTimelines,
  };
}
