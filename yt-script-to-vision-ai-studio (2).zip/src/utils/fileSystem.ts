import JSZip from 'jszip';
import { GeneratedItem, SceneAudioData } from '../types';

export async function downloadAllZip(
  readyItems: GeneratedItem[],
  audioMap: Record<number, SceneAudioData>,
  compiledVideoBlob: Blob | null,
  aspectRatio: string
): Promise<void> {
  if (!readyItems.length) {
    throw new Error('No generated scene items ready to download.');
  }

  const zip = new JSZip();

  for (let i = 0; i < readyItems.length; i++) {
    const item = readyItems[i];
    try {
      if (item.imageBlob) {
        zip.file(item.filename, item.imageBlob);
      } else {
        const sourceUrl = item.localBlobUrl || item.imageUrl;
        if (sourceUrl) {
          const res = await fetch(sourceUrl);
          const blob = await res.blob();
          zip.file(item.filename, blob);
        }
      }

      // Add script narration & prompt text file
      const infoContent = `SCENE #${item.sceneNumber}
SCRIPT NARRATION:
${item.scriptPart}

IMAGE PROMPT:
${item.prompt}

STYLE: ${item.style}
ENGINE: ${item.engine}
`;
      zip.file(item.txtFilename, infoContent);

      // Add scene voice audio
      const audio = audioMap[item.index];
      if (audio?.blob) {
        zip.file(item.audioFilename, audio.blob);
      }
    } catch (err) {
      console.warn(`Could not add scene ${i + 1} to zip:`, err);
    }
  }

  // Include compiled video if ready
  if (compiledVideoBlob) {
    const isShort = aspectRatio === '9:16';
    const videoName = isShort
      ? `youtube_short_1080x1920_${Date.now()}.mp4`
      : `youtube_video_1920x1080_${Date.now()}.mp4`;
    zip.file(videoName, compiledVideoBlob);
  }

  const content = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = `yt_studio_1080p_assets_${Date.now()}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function saveItemToDirectory(
  dirHandle: FileSystemDirectoryHandle,
  item: GeneratedItem,
  audioData?: SceneAudioData
): Promise<void> {
  try {
    // Save image
    if (item.imageBlob || item.localBlobUrl || item.imageUrl) {
      const fileHandle = await dirHandle.getFileHandle(item.filename, { create: true });
      const writable = await fileHandle.createWritable();
      const res = await fetch(item.localBlobUrl || item.imageUrl!);
      const blob = await res.blob();
      await writable.write(blob);
      await writable.close();
    }

    // Save prompt txt
    const txtHandle = await dirHandle.getFileHandle(item.txtFilename, { create: true });
    const txtWritable = await txtHandle.createWritable();
    await txtWritable.write(item.prompt);
    await txtWritable.close();

    // Save audio
    if (audioData?.blob) {
      const audioHandle = await dirHandle.getFileHandle(item.audioFilename, { create: true });
      const audioWritable = await audioHandle.createWritable();
      await audioWritable.write(audioData.blob);
      await audioWritable.close();
    }
  } catch (err) {
    console.warn(`Auto-save to directory failed for ${item.filename}:`, err);
  }
}
