let globalAudioCtx: AudioContext | null = null;

export function getAudioContext(): AudioContext {
  if (!globalAudioCtx) {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    globalAudioCtx = new AudioCtx();
  }
  if (globalAudioCtx.state === 'suspended') {
    globalAudioCtx.resume();
  }
  return globalAudioCtx;
}

export function audioBufferToWav(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const format = 1; // 1 = 16-bit PCM
  const bitDepth = 16;
  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;
  const byteRate = sampleRate * blockAlign;
  const dataSize = buffer.length * blockAlign;
  const headerSize = 44;
  const totalSize = headerSize + dataSize;
  const arrayBuffer = new ArrayBuffer(totalSize);
  const dataView = new DataView(arrayBuffer);

  function writeString(offset: number, string: string) {
    for (let i = 0; i < string.length; i++) {
      dataView.setUint8(offset + i, string.charCodeAt(i));
    }
  }

  // RIFF identifier
  writeString(0, 'RIFF');
  // RIFF chunk length
  dataView.setUint32(4, totalSize - 8, true);
  // RIFF type
  writeString(8, 'WAVE');
  // format chunk identifier
  writeString(12, 'fmt ');
  // format chunk length
  dataView.setUint32(16, 16, true);
  // sample format (1 = PCM)
  dataView.setUint16(20, format, true);
  // channel count
  dataView.setUint16(22, numChannels, true);
  // sample rate
  dataView.setUint32(24, sampleRate, true);
  // byte rate
  dataView.setUint32(28, byteRate, true);
  // block align
  dataView.setUint16(32, blockAlign, true);
  // bits per sample
  dataView.setUint16(34, bitDepth, true);
  // data chunk identifier
  writeString(36, 'data');
  // data chunk length
  dataView.setUint32(40, dataSize, true);

  // Write interleaved 16-bit PCM samples
  let offset = 44;
  const channels: Float32Array[] = [];
  for (let c = 0; c < numChannels; c++) {
    channels.push(buffer.getChannelData(c));
  }

  for (let i = 0; i < buffer.length; i++) {
    for (let c = 0; c < numChannels; c++) {
      let sample = channels[c][i];
      sample = Math.max(-1, Math.min(1, sample));
      const int16 = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
      dataView.setInt16(offset, int16, true);
      offset += 2;
    }
  }

  return new Blob([dataView], { type: 'audio/wav' });
}

/**
 * Trims leading and trailing dead silence from an AudioBuffer so each scene's
 * voice starts immediately at scene start and ends immediately when speech finishes.
 */
export function trimSilenceFromAudioBuffer(
  rawBuffer: AudioBuffer,
  audioCtx: AudioContext,
  threshold: number = 0.008
): AudioBuffer {
  const sampleRate = rawBuffer.sampleRate;
  const numChannels = rawBuffer.numberOfChannels;
  const totalSamples = rawBuffer.length;
  if (totalSamples === 0) return rawBuffer;

  const ch0 = rawBuffer.getChannelData(0);
  let startSample = 0;
  let endSample = totalSamples - 1;

  while (startSample < totalSamples && Math.abs(ch0[startSample]) < threshold) {
    startSample++;
  }
  while (endSample > startSample && Math.abs(ch0[endSample]) < threshold) {
    endSample--;
  }

  // Keep a small natural breath padding (40ms before, 80ms after)
  const padStart = Math.floor(0.04 * sampleRate);
  const padEnd = Math.floor(0.08 * sampleRate);
  startSample = Math.max(0, startSample - padStart);
  endSample = Math.min(totalSamples - 1, endSample + padEnd);

  const trimmedLength = endSample - startSample + 1;
  if (trimmedLength < Math.floor(0.25 * sampleRate) || trimmedLength >= totalSamples * 0.98) {
    return rawBuffer;
  }

  const out = audioCtx.createBuffer(numChannels, trimmedLength, sampleRate);
  const fadeSamples = Math.min(Math.floor(0.015 * sampleRate), Math.floor(trimmedLength / 4));

  for (let ch = 0; ch < numChannels; ch++) {
    const src = rawBuffer.getChannelData(ch);
    const dest = out.getChannelData(ch);
    dest.set(src.subarray(startSample, endSample + 1));

    for (let i = 0; i < fadeSamples; i++) {
      dest[i] *= i / fadeSamples;
      dest[trimmedLength - 1 - i] *= i / fadeSamples;
    }
  }

  return out;
}

export async function synthesizeGoogleVoiceFallback(
  text: string,
  voice: string = 'M1'
): Promise<{ blob: Blob; audioBuffer: AudioBuffer; duration: number; url: string; originalDuration: number }> {
  const audioCtx = getAudioContext();
  const res = await fetch(
    `/api/tts?text=${encodeURIComponent(text.trim())}&voice=${encodeURIComponent(voice || 'M1')}`
  );
  if (!res.ok) {
    throw new Error(`TTS fallback failed with status ${res.status}`);
  }
  const arrayBuffer = await res.arrayBuffer();
  const decodedBuffer = await audioCtx.decodeAudioData(arrayBuffer.slice(0));
  const audioBuffer = trimSilenceFromAudioBuffer(decodedBuffer, audioCtx);
  const wavBlob = audioBufferToWav(audioBuffer);
  const url = URL.createObjectURL(wavBlob);
  return {
    blob: wavBlob,
    audioBuffer,
    duration: audioBuffer.duration,
    url,
    originalDuration: decodedBuffer.duration,
  };
}

export async function synthesizeAudexumVoice(
  text: string,
  key: string = 'sk_live_OE8MgVBuVKeE-FUAxTxWSCC8h-GSi9XcUETVrzDZrVk',
  voice: string = 'M1',
  speed: number = 1.05,
  backend: string = 'supertonic',
  steps: number = 8
): Promise<{ blob: Blob; audioBuffer: AudioBuffer; duration: number; url: string; originalDuration: number }> {
  // Strict Audexum backend validation: '^(supertonic|kokoro|qwen|v3)$'
  let validBackend = 'supertonic';
  if (backend === 'kokoro' || backend === 'qwen' || backend === 'v3') {
    validBackend = backend;
  } else if (backend === 'default') {
    validBackend = 'v3';
  } else {
    validBackend = 'supertonic';
  }

  let payload: any;
  if (voice === 'Atlas') {
    payload = {
      text: text.trim(),
      voice: 'Atlas',
      backend: 'v3',
    };
  } else {
    payload = {
      text: text.trim(),
      backend: validBackend,
      voice: voice || 'M1',
      lang: 'en',
      speed: isNaN(speed) ? 1.05 : speed,
      steps: steps || 8,
    };
  }

  const targetUrl = 'https://audexum.com/api/synthesize';
  const headers: Record<string, string> = {
    'Authorization': `Bearer ${key}`,
    'Content-Type': 'application/json',
  };

  let response: Response | null = null;
  try {
    // Attempt through our internal CORS proxy first
    response = await fetch(`/api/proxy?url=${encodeURIComponent(targetUrl)}`, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });

    // Only retry direct if it was a proxy gateway error (502/504), not 401/402/422 credit/auth errors
    if (!response.ok && response.status >= 500) {
      console.warn(`Proxy Audexum returned ${response.status}. Retrying direct...`);
      response = await fetch(targetUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload),
      });
    }
  } catch (err) {
    console.warn('Audexum request failed, attempting fallback...', err);
  }

  // If Audexum succeeded, decode and trim watermark; on any decode failure or HTTP error, fallback cleanly
  if (response && response.ok) {
    try {
      const contentType = response.headers.get('content-type') || '';
      if (!contentType.includes('json')) {
        const blob = await response.blob();
        const arrayBuffer = await blob.arrayBuffer();

        if (arrayBuffer.byteLength > 256) {
          const audioCtx = getAudioContext();
          const rawAudioBuffer = await audioCtx.decodeAudioData(arrayBuffer.slice(0));

          // Cut the last 1.6 seconds from Audexum audio to remove the "Made with..." watermark
          const shouldCut = rawAudioBuffer.duration > 2.2;
          const cutBuffer = shouldCut
            ? cutWatermarkFromAudioBuffer(rawAudioBuffer, audioCtx, 1.6)
            : rawAudioBuffer;
          const audioBuffer = trimSilenceFromAudioBuffer(cutBuffer, audioCtx);

          const duration = audioBuffer.duration;
          const trimmedWavBlob = audioBufferToWav(audioBuffer);
          const url = URL.createObjectURL(trimmedWavBlob);

          return {
            blob: trimmedWavBlob,
            audioBuffer,
            duration,
            url,
            originalDuration: rawAudioBuffer.duration,
          };
        }
      }
    } catch (decodeErr) {
      console.warn('Audexum audio decode failed, falling back to neural TTS:', decodeErr);
    }
  }

  // Seamlessly fallback to server neural TTS (supports M1, F1, Atlas & unlimited length)
  const status = response ? response.status : 'offline';
  console.info(`[Audexum TTS ${status}] Seamlessly falling back to neural voice synthesis...`);
  try {
    return await synthesizeGoogleVoiceFallback(text, voice);
  } catch (fallbackErr: any) {
    const errText = response ? await response.text().catch(() => '') : '';
    throw new Error(`TTS Error (${status}): ${errText || fallbackErr.message}`);
  }
}

/**
 * Cuts the last 1.6 seconds from the audio buffer to completely eliminate
 * the "Made with..." watermark, applying a clean 30ms anti-pop micro fade-out.
 */
export function cutWatermarkFromAudioBuffer(
  rawBuffer: AudioBuffer,
  audioCtx: AudioContext,
  cutSeconds: number = 1.6
): AudioBuffer {
  const sampleRate = rawBuffer.sampleRate;
  const numChannels = rawBuffer.numberOfChannels;
  const totalSamples = rawBuffer.length;

  // Calculate cut length in samples (1.6s)
  const cutSamples = Math.floor(cutSeconds * sampleRate);
  let targetSamples = totalSamples - cutSamples;

  // Minimum safety floor: don't allow target length < 0.3s
  if (targetSamples < Math.floor(0.3 * sampleRate)) {
    targetSamples = Math.max(Math.floor(0.3 * sampleRate), Math.floor(totalSamples * 0.4));
  }

  const trimmedBuffer = audioCtx.createBuffer(numChannels, targetSamples, sampleRate);

  for (let ch = 0; ch < numChannels; ch++) {
    const src = rawBuffer.getChannelData(ch);
    const dest = trimmedBuffer.getChannelData(ch);
    dest.set(src.subarray(0, targetSamples));

    // Smooth 30ms anti-click micro fade-out at the exact cut point
    const fadeSamples = Math.min(Math.floor(0.03 * sampleRate), targetSamples);
    for (let i = 0; i < fadeSamples; i++) {
      const idx = targetSamples - fadeSamples + i;
      dest[idx] *= (fadeSamples - i) / fadeSamples;
    }
  }

  return trimmedBuffer;
}

export interface SceneTrackPlan {
  sceneIndex: number;
  buffer: AudioBuffer | null;
  duration: number; // in seconds
}

export interface MasterTrackResult {
  masterBuffer: AudioBuffer;
  totalDuration: number;
  sceneTimelines: Array<{
    sceneIndex: number;
    start: number;
    end: number;
    duration: number;
    voiceEnd: number;
  }>;
}

/**
 * Creates a silent audio buffer of specified length.
 */
export function createSilentAudioBuffer(durationSeconds: number, audioCtx?: AudioContext): AudioBuffer {
  const ctx = audioCtx || getAudioContext();
  const sampleRate = ctx.sampleRate || 44100;
  const numSamples = Math.max(1, Math.floor(durationSeconds * sampleRate));
  return ctx.createBuffer(2, numSamples, sampleRate);
}

/**
 * Assembles all scene voiceovers into a single continuous Master Audio Buffer.
 * Default pauseBetweenScenesSec = 0.0 ensures each scene's image shows for
 * EXACTLY the duration of its voice, with zero extra time or gaps.
 * Provides micro-fades at cut points to prevent audio clicks and guarantee 100% smooth flow.
 */
export function buildMasterAudioTrack(
  tracks: SceneTrackPlan[],
  audioCtx?: AudioContext,
  pauseBetweenScenesSec: number = 0.0 // 0.0s: Image is shown for EXACTLY the voice length
): MasterTrackResult {
  const ctx = audioCtx || getAudioContext();
  const sampleRate = ctx.sampleRate || 44100;

  // Calculate timeline positions
  let currentOffset = 0;
  const sceneTimelines = tracks.map((track) => {
    const voiceDuration = track.buffer ? track.buffer.duration : Math.max(1.5, track.duration || 3.0);
    const start = currentOffset;
    const voiceEnd = start + voiceDuration;
    const end = voiceEnd + pauseBetweenScenesSec;
    const duration = end - start;
    currentOffset = end;
    return {
      sceneIndex: track.sceneIndex,
      start,
      end,
      duration,
      voiceEnd,
    };
  });

  const totalDuration = Math.max(0.1, currentOffset);
  const totalSamples = Math.ceil(totalDuration * sampleRate) + sampleRate; // +1s safety tail

  // Create 2-channel stereo master buffer
  const masterBuffer = ctx.createBuffer(2, totalSamples, sampleRate);
  const masterLeft = masterBuffer.getChannelData(0);
  const masterRight = masterBuffer.getChannelData(1);

  // Blend each scene's audio into the master track
  tracks.forEach((track, i) => {
    const timeline = sceneTimelines[i];
    if (!track.buffer) return;

    const startSample = Math.round(timeline.start * sampleRate);
    const sceneBuffer = track.buffer;
    const sceneSamples = sceneBuffer.length;
    const channels = sceneBuffer.numberOfChannels;

    const srcLeft = sceneBuffer.getChannelData(0);
    const srcRight = channels > 1 ? sceneBuffer.getChannelData(1) : srcLeft;

    // 5ms micro fade-in and 5ms micro fade-out to eliminate clicks/pops between scene cuts
    const fadeInSamples = Math.min(Math.round(0.005 * sampleRate), sceneSamples);
    const fadeOutSamples = Math.min(Math.round(0.005 * sampleRate), sceneSamples);

    for (let s = 0; s < sceneSamples; s++) {
      const targetIdx = startSample + s;
      if (targetIdx >= totalSamples) break;

      let gain = 1.0;
      if (s < fadeInSamples) {
        gain = s / fadeInSamples;
      } else if (s > sceneSamples - fadeOutSamples) {
        gain = (sceneSamples - s) / fadeOutSamples;
      }

      masterLeft[targetIdx] += srcLeft[s] * gain;
      masterRight[targetIdx] += srcRight[s] * gain;
    }
  });

  return {
    masterBuffer,
    totalDuration,
    sceneTimelines,
  };
}

